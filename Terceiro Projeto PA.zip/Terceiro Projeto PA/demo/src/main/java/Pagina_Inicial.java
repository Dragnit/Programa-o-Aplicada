import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Pagina_Inicial extends JFrame 
{
    private String utilizador;
    private int id;
    private String tipo;
    private int num_notificacoes;
    
    // construtor
    public Pagina_Inicial(String utilizador, int id, String tipo, int num_notificacoes) 
    {
        this.utilizador = utilizador;
        this.id = id;
        this.tipo = tipo;
        System.out.println(tipo);
        this.num_notificacoes = num_notificacoes;
        
        setTitle("Menu de " + tipo + " - " + utilizador);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Layout principal com BorderLayout
        setLayout(new BorderLayout());
        
        // Painel esquerdo - Informação do utilizador
        JPanel painelInfo = criarPainelInformacao();
        
        // Painel direito - Botões de ação (CORREÇÃO AQUI)
        JPanel painelBotoes;
        if(tipo.equals("Gestor")) 
        {
            painelBotoes = criarPainelBotoesGestor();
        } 
        else if (tipo.equals("Fabricante")) 
        {
            painelBotoes = criarPainelBotoesFabricante();
        } 
        else 
        {
            painelBotoes = criarPainelBotoesTecnico();
        }
        
        // Adicionar painéis ao frame
        add(painelInfo, BorderLayout.WEST);
        add(painelBotoes, BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    private JPanel criarPainelInformacao() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createTitledBorder("Informação utilizador"));
        painel.setPreferredSize(new Dimension(250, 0));
        painel.setBackground(Color.LIGHT_GRAY);
        
        // Adicionar informações do utilizador
        painel.add(Box.createVerticalStrut(20));
        
        JLabel lblTitulo = new JLabel("Dados do Utilizador");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblTitulo);
        
        painel.add(Box.createVerticalStrut(20));
        
        JLabel lblNome = new JLabel("Nome: " + utilizador);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblNome);
        
        painel.add(Box.createVerticalStrut(10));
        
        JLabel lblId = new JLabel("ID: " + id);
        lblId.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblId);
        
        painel.add(Box.createVerticalStrut(10));
        
        JLabel lblTipo = new JLabel("Tipo: " + tipo);
        lblTipo.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblTipo);
        
        painel.add(Box.createVerticalStrut(10));
        
        JLabel lblNotificacoes = new JLabel("Notificações: " + num_notificacoes);
        lblNotificacoes.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblNotificacoes);
        
        painel.add(Box.createVerticalGlue());
        
        return painel;
    }
    
    private JPanel criarPainelBotoesGestor() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(15, 1, 5, 5));
        painel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Botões de ação - Gestor"), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        
        // Adicionar botões do Gestor
        painel.add(new JLabel("=== Menu de Gestor ===", JLabel.CENTER));
        painel.add(criarBotao("1. Registar Gestor"));
        painel.add(criarBotao("2. Remover Utilizador"));
        painel.add(criarBotao("3. Pesquisar Utilizador por username"));
        painel.add(criarBotao("4. Listar todos os Utilizadores por tipo"));
        painel.add(criarBotao("5. Listar todos os Utilizadores"));
        painel.add(criarBotao("6. Alterar Informações de um Utilizador"));
        painel.add(criarBotao("7. Inserir Licença"));
        painel.add(criarBotao("8. Aceitar Pedido de Certificação"));
        painel.add(criarBotao("9. Listar todas as Certificações"));
        painel.add(criarBotao("10. Pesquisar por Certificação"));
        painel.add(criarBotao("11. Pesquisar por Equipamento"));
        painel.add(criarBotao("12. Arquivar uma Certificação"));
        painel.add(criarBotao("13. Ver Notificações (" + num_notificacoes + ")"));
        painel.add(criarBotao("14. Sair"));
        
        return painel;
    }
    
    private JPanel criarPainelBotoesFabricante() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(12, 1, 5, 5));
        painel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Botões de ação - Fabricante"), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        
        // Adicionar botões do Fabricante
        painel.add(new JLabel("=== Menu de Fabricante ===", JLabel.CENTER));
        painel.add(criarBotao("1. Visualizar informação"));
        painel.add(criarBotao("2. Alterar informação"));
        painel.add(criarBotao("3. Pedir para Remover Conta"));
        painel.add(criarBotao("4. Adicionar Equipamento"));
        painel.add(criarBotao("5. Listar Equipamentos"));
        painel.add(criarBotao("6. Pesquisar Equipamentos"));
        painel.add(criarBotao("7. Realizar Pedido de Certificação"));
        painel.add(criarBotao("8. Listar Certificações"));
        painel.add(criarBotao("9. Pesquisar por Certificação"));
        painel.add(criarBotao("10. Ver Notificações (" + num_notificacoes + ")"));
        painel.add(criarBotao("11. Sair"));
        
        return painel;
    }
    
    private JPanel criarPainelBotoesTecnico() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(10, 1, 5, 5));
        painel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Botões de ação - Técnico"),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        
        // Adicionar botões do Técnico
        painel.add(new JLabel("=== Menu de Técnico ===", JLabel.CENTER));
        painel.add(criarBotao("1. Visualizar informação"));
        painel.add(criarBotao("2. Alterar informação"));
        painel.add(criarBotao("3. Pedidos de Certificação"));
        painel.add(criarBotao("4. Listar Pedidos de Certificação"));
        painel.add(criarBotao("5. Inserir Resultados de Certificação"));
        painel.add(criarBotao("6. Terminar Certificação"));
        painel.add(criarBotao("7. Remoção de Conta"));
        painel.add(criarBotao("8. Ver Notificações (" + num_notificacoes + ")"));
        painel.add(criarBotao("9. Sair"));
        
        return painel;
    }
    
    private JButton criarBotao(String texto) 
    {
        JButton botao = new JButton(texto);
        botao.addActionListener((ActionEvent e) -> {
            // Aqui você pode implementar as ações específicas
            if (texto.contains("Sair")) 
            {
                int resposta = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja sair?", "Confirmar Saída", JOptionPane.YES_NO_OPTION);
                if (resposta == JOptionPane.YES_OPTION) 
                {
                    System.out.println("Adeus " + utilizador + "!");
                    this.dispose();
                    Main.caixaDeDialogo();
                }
            } 
        });
        return botao;
    }
    
}