import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class Pagina_Inicial extends JFrame 
{
    private String utilizador;
    private int id;
    private String tipo;
    private int num_notificacoes;
    
    // construtor
    /**
     *  Cria uma nova instância da página inicial do utilizador.
     *  Este construtor inicializa a interface gráfica com base no tipo de utilizador (Gestor, Fabricante ou Técnico),
     *  exibindo informações relevantes e botões de ação correspondentes.
     * 
     * @author Guilherme Rodrigues
     * 
     * @param utilizador
     * @param id
     * @param tipo
     * @param num_notificacoes
     */
    public Pagina_Inicial(String utilizador, int id, String tipo, int num_notificacoes) 
    {
        this.utilizador = utilizador;
        this.id = id;
        this.tipo = tipo;
        System.out.println(tipo);
        this.num_notificacoes = num_notificacoes;
        
        setTitle("Menu de " + tipo + " - " + utilizador);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Layout principal com BorderLayout
        setLayout(new BorderLayout());
        
        // Painel esquerdo - Informação do utilizador
        JPanel painelInfo = criarPainelInformacao();
        
        // Painel direito - Botões de ação
        JPanel painelBotoes;
        if(tipo.equals("Gestor")) 
        {
            painelBotoes = criarPainelBotoesGestor();
        } 
        else if (tipo.equals("Fabricante")) 
        {
            painelBotoes = criarPainelBotoesFabricante();
        } 
        else 
        {
            painelBotoes = criarPainelBotoesTecnico();
        }
        
        // Adicionar painéis ao frame
        add(painelInfo, BorderLayout.WEST);
        add(painelBotoes, BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    /**
     *  Cria um painel com informações do utilizador.
     *  Este painel exibe o nome, ID, tipo de utilizador e número de notificações do utilizador.
     *  O painel é estilizado com bordas, cores e fontes apropriadas para melhorar a legibilidade.  
     * 
     *  @author Guilherme Rodrigues
     * 
     * @return
     */
    private JPanel criarPainelInformacao() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createTitledBorder("Informação utilizador"));
        painel.setPreferredSize(new Dimension(250, 0));
        painel.setBackground(Color.LIGHT_GRAY);
        
        // Adicionar informações do utilizador
        painel.add(Box.createVerticalStrut(20));
        
        JLabel lblTitulo = new JLabel("Dados do Utilizador");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblTitulo);
        
        painel.add(Box.createVerticalStrut(20));
        
        JLabel lblNome = new JLabel("Nome: " + utilizador);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblNome);
        
        painel.add(Box.createVerticalStrut(10));
        
        JLabel lblId = new JLabel("ID: " + id);
        lblId.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblId);
        
        painel.add(Box.createVerticalStrut(10));
        
        JLabel lblTipo = new JLabel("Tipo: " + tipo);
        lblTipo.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblTipo);
        
        painel.add(Box.createVerticalStrut(10));
        
        JLabel lblNotificacoes = new JLabel("Notificações: " + num_notificacoes);
        lblNotificacoes.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(lblNotificacoes);
        
        painel.add(Box.createVerticalGlue());
        
        return painel;
    }
    
    /**
     *  Cria um painel com botões de ação específicos para o tipo de utilizador.
     *  Dependendo do tipo de utilizador (Gestor, Fabricante ou Técnico), diferentes botões são adicionados ao painel.
     *  Cada botão tem uma ação associada que será executada quando o botão for clicado.
     * 
     *  @author Guilherme Rodrigues
     * 
     * @return
     */
    private JPanel criarPainelBotoesGestor() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(15, 1, 5, 5));
        painel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Botões de ação - Gestor"), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        
        // Adicionar botões do Gestor
        painel.add(new JLabel("=== Menu de Gestor ===", JLabel.CENTER));
        painel.add(criarBotao("1. Registar Gestor"));
        painel.add(criarBotao("2. Remover Utilizador"));
        painel.add(criarBotao("3. Pesquisar Utilizador por username"));
        painel.add(criarBotao("4. Listar todos os Utilizadores por tipo"));
        painel.add(criarBotao("5. Listar todos os Utilizadores"));
        painel.add(criarBotao("6. Alterar Informações de um Utilizador"));
        painel.add(criarBotao("7. Inserir Licença"));
        painel.add(criarBotao("8. Aceitar Pedido de Certificação"));
        painel.add(criarBotao("9. Listar todas as Certificações"));
        painel.add(criarBotao("10. Pesquisar por Certificação"));
        painel.add(criarBotao("11. Pesquisar por Equipamento"));
        painel.add(criarBotao("12. Arquivar uma Certificação"));
        painel.add(criarBotao("13. Ver Notificações (" + num_notificacoes + ")"));
        painel.add(criarBotao("14. Sair"));
        
        return painel;
    }
    
    /**
     *  Cria um painel com botões de ação específicos para o tipo de utilizador Fabricante.
     *  Este painel contém botões para visualizar e alterar informações, gerenciar equipamentos e certificações,
     *  além de opções para sair e ver notificações.
     * 
     *  @author Guilherme Rodrigues
     * 
     * @return
     */
    private JPanel criarPainelBotoesFabricante() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(12, 1, 5, 5));
        painel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Botões de ação - Fabricante"), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        
        // Adicionar botões do Fabricante
        painel.add(new JLabel("=== Menu de Fabricante ===", JLabel.CENTER));
        painel.add(criarBotao("1. Visualizar informação"));
        painel.add(criarBotao("2. Alterar informação"));
        painel.add(criarBotao("3. Remoção de Conta"));
        painel.add(criarBotao("4. Adicionar Equipamento"));
        painel.add(criarBotao("5. Listar Equipamentos"));
        painel.add(criarBotao("6. Pesquisar Equipamentos"));
        painel.add(criarBotao("7. Realizar Pedido de Certificação"));
        painel.add(criarBotao("8. Listar Certificações"));
        painel.add(criarBotao("9. Pesquisar por Certificação"));
        painel.add(criarBotao("10. Notificações (" + num_notificacoes + ")"));
        painel.add(criarBotao("11. Sair"));
        
        return painel;
    }
    
    /**
     *  Cria um painel com botões de ação específicos para o tipo de utilizador Técnico.
     *  Este painel contém botões para visualizar e alterar informações, gerenciar pedidos de certificação,
     *  além de opções para sair e ver notificações.
     * 
     *  @author Guilherme Rodrigues
     * 
     * @return
     */
    private JPanel criarPainelBotoesTecnico() 
    {
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(10, 1, 5, 5));
        painel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Botões de ação - Técnico"),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        
        // Adicionar botões do Técnico
        painel.add(new JLabel("=== Menu de Técnico ===", JLabel.CENTER));
        painel.add(criarBotao("1. Visualizar informação"));
        painel.add(criarBotao("2. Alterar informação"));
        painel.add(criarBotao("3. Pedidos de Certificação"));
        painel.add(criarBotao("4. Listar Pedidos de Certificação"));
        painel.add(criarBotao("5. Inserir Resultados de Certificação"));
        painel.add(criarBotao("6. Terminar Certificação"));
        painel.add(criarBotao("7. Remoção de Conta"));
        painel.add(criarBotao("8. Ver as suas Notificações (" + num_notificacoes + ")"));
        painel.add(criarBotao("9. Sair"));
        
        return painel;
    }
    
    /**
     * Método para criar um botão com ação associada que depende do texto do botão.
     * 
     * @author Guilherme Rodrigues
     * 
     * @param texto
     * @return
     */
    private JButton criarBotao(String texto) 
    {
        JButton botao = new JButton(texto);
        botao.addActionListener((ActionEvent e) -> {
            // Aqui você pode implementar as ações específicas
            if (texto.contains("Sair")) 
            {
                int resposta = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja sair?", "Confirmar Saída", JOptionPane.YES_NO_OPTION);
                if (resposta == JOptionPane.YES_OPTION) 
                {
                    System.out.println("Adeus " + utilizador + "!");
                    this.dispose();
                    Main.caixaDeDialogo();
                }
            } 
            else if(texto.contains("Registar Gestor"))
            {
                Registo janela = new Registo(); // NÃO monta nada ainda
                janela.RegistoGestor();         // monta só o layout do gestor
                janela.setSize(600, 700);
                janela.setLocationRelativeTo(null);
                janela.setVisible(true);
            }
            else if(texto.contains("Remover Utilizador"))
            {
                abrirJanelaRemoverUtilizador();
            }
            else if(texto.contains("Pesquisar Utilizador por username"))
            {
                abrirJanelaBuscaUtilizador();
            }
            else if(texto.contains("Listar todos os Utilizadores por tipo"))
            {
                abrirJanelaBuscaTipo();
            }
            else if(texto.contains("Listar todos os Utilizadores"))
            {
                abrirJanelaBuscaTodos();
            }
            else if(texto.contains("Alterar Informações de um Utilizador"))
            {
                abrirJanelaAtualizarUtilizador();
            }
            else if(texto.contains("Inserir Licença"))
            {
                abrirJanelaInserirLicenca();
            }
            else if(texto.contains("Aceitar Pedido de Certificação"))
            {
               abrirJanelaAceitarPedidoCertificacao();
            }
            else if(texto.contains("Listar todas as Certificações"))
            {
                abrirJanelaListarCertificacoes(tipo);
            }
            else if(texto.contains("Pesquisar por Certificação"))
            {
                abrirJanelaPesquisarCertificacao();                
            }
            else if(texto.contains("Pesquisar por Equipamento"))
            {
                abrirJanelaPesquisarEquipamento(tipo, id);
            }
            else if(texto.contains("Arquivar uma Certificação"))
            {
                abrirJanelaArquivarCertificacao();
            }
            else if(texto.contains("Ver Notificações"))
            {
                listarNotificacoes();
            }
            else if(texto.contains("Visualizar informação")) 
            {
                abrirJanelaVisualizarInformacao(id);
            }
            else if(texto.contains("Alterar informação"))
            {
                abrirJanelaAtualizarUtilizador(id);
            }
            else if(texto.equals("3. Pedidos de Certificação"))
            {
                abrirJanelaInserirCertificacao(id);
            }
            else if(texto.equals("4. Listar Pedidos de Certificação"))
            {
                abrirJanelaPesquisarCertificacao(id);
            }
            else if(texto.equals("5. Inserir Resultados de Certificação"))
            {
                abrirJanelaInserirResultadosCertificacao(id);
            }
            else if(texto.equals("6. Terminar Certificação"))
            {
                abrirJanelaTerminarCertificacao(id);
            }
            else if(texto.contains(" Remoção de Conta"))
            {
                abrirJanelaPedidoRemocao(id);
            }
            else if(texto.contains("Ver as suas Notificações"))
            {
                listarNotificacoesTecnico(tipo, id);
            }
            else if(texto.contains("Adicionar Equipamento"))
            {
                abrirJanelaRegistarEquipamento(id);
            }
            else if(texto.contains("Listar Equipamentos"))
            {
                abrirJanelaPesquisarEquipamento(tipo, id);
            }
            else if(texto.contains("Pesquisar Equipamentos"))
            {
                abrirJanelaPesquisarEquipamento(tipo, id);
            }
            else if(texto.contains("Realizar Pedido de Certificação"))
            {
                abrirJanelaRealizarPedidoCertificacao();
            }
            else if(texto.contains("Listar Certificações"))
            {
                abrirJanelaPesquisarCertificacao(id);
            }
            else if(texto.contains("10. Notificações"))
            {
                abrirJanelaNotificacoesFabricante();
            }

        });
        return botao;
    }
    
    /**
     *  Método para abrir uma janela de remoção de utilizador.
     *  Esta janela permite ao gestor buscar um utilizador pelo ID e exibir suas informações.
     *  Se o utilizador estiver ativo, o gestor pode optar por desativá-lo.
     *  Caso o utilizador já esteja desativado, uma mensagem apropriada é exibida.
     * 
     * @author Guilherme Rodrigues
     */
    private void abrirJanelaRemoverUtilizador() 
    {
        JFrame janelaRemover = new JFrame("Remover Utilizador");
        janelaRemover.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaRemover.setSize(600, 500);
        janelaRemover.setLocationRelativeTo(this);
        janelaRemover.setLayout(new GridBagLayout());
        janelaRemover.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Remover Utilizador", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaRemover.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo ID do Utilizador
        JLabel labelId = new JLabel("ID do Utilizador:");
        labelId.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaRemover.add(labelId, gbc);

        JTextField campoIdUtilizador = new JTextField();
        campoIdUtilizador.setPreferredSize(new Dimension(250, 35));
        campoIdUtilizador.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRemover.add(campoIdUtilizador, gbc);

        // Label para mostrar informações do utilizador
        JLabel labelInfo = new JLabel(" ");
        labelInfo.setFont(new Font("Arial", Font.PLAIN, 14));
        labelInfo.setForeground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaRemover.add(labelInfo, gbc);
        gbc.gridwidth = 1;

        // Botão Buscar Utilizador
        JButton botaoBuscar = new JButton("Buscar Utilizador");
        botaoBuscar.setPreferredSize(new Dimension(200, 40));
        botaoBuscar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoBuscar.setBackground(new Color(70, 130, 180));
        botaoBuscar.setForeground(Color.WHITE);
        botaoBuscar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String idTexto = campoIdUtilizador.getText().trim();
                
                if (idTexto.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaRemover, "Por favor, insira o ID do utilizador!");
                    return;
                }
                
                try 
                {
                    int idUtilizador = Integer.parseInt(idTexto);
                    
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    
                    String sql = "SELECT nome_utilizador, username_utilizador, email_utilizador, tipo, desativado FROM utilizador WHERE id_utilizador = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, idUtilizador);
                    ResultSet rs = pstmt.executeQuery();
                    
                    if (rs.next()) 
                    {
                        String nome = rs.getString("nome_utilizador");
                        String username = rs.getString("username_utilizador");
                        String email = rs.getString("email_utilizador");
                        String tipo = rs.getString("tipo");
                        boolean desativado = rs.getBoolean("desativado");
                        
                        if (desativado) 
                        {
                            labelInfo.setText("<html><div style='text-align: center;'>" +
                                            "<b>Nome:</b> " + nome + "<br>" +
                                            "<b>Username:</b> " + username + "<br>" +
                                            "<b>Email:</b> " + email + "<br>" +
                                            "<b>Tipo:</b> " + tipo + "<br>" +
                                            "<span style='color: red;'><b>Status:</b> JÁ DESATIVADO</span>" +
                                            "</div></html>");
                        } 
                        else 
                        {
                            labelInfo.setText("<html><div style='text-align: center;'>" +
                                            "<b>Nome:</b> " + nome + "<br>" +
                                            "<b>Username:</b> " + username + "<br>" +
                                            "<b>Email:</b> " + email + "<br>" +
                                            "<b>Tipo:</b> " + tipo + "<br>" +
                                            "<span style='color: green;'><b>Status:</b> ATIVO</span>" +
                                            "</div></html>");
                        }
                    } 
                    else 
                    {
                        labelInfo.setText("<html><span style='color: red;'>Utilizador não encontrado!</span></html>");
                    }
                    
                    rs.close();
                    pstmt.close();
                    conn.close();
                    
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(janelaRemover, "ID deve ser um número válido!");
                } 
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(janelaRemover, "Erro ao buscar utilizador: " + ex.getMessage());
                    System.out.println("Erro SQL: " + ex.getMessage());
                }
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 15, 10, 15);
        janelaRemover.add(botaoBuscar, gbc);
        gbc.gridwidth = 1;

        // Botões de ação
        gbc.insets = new Insets(20, 15, 10, 15);
        
        JButton botaoRemover = new JButton("Remover Utilizador");
        botaoRemover.setPreferredSize(new Dimension(200, 40));
        botaoRemover.setFont(new Font("Arial", Font.BOLD, 14));
        botaoRemover.setBackground(new Color(220, 20, 60));
        botaoRemover.setForeground(Color.WHITE);
        botaoRemover.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String idTexto = campoIdUtilizador.getText().trim();
                
                if (idTexto.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaRemover, "Por favor, primeiro busque um utilizador!");
                    return;
                }
                
                try 
                {
                    int idUtilizador = Integer.parseInt(idTexto);
                    
                    // Confirmação antes de remover
                    int opcao = JOptionPane.showConfirmDialog(janelaRemover, 
                        "Tem certeza que deseja desativar este utilizador?\n" +
                        "Esta ação irá marcar o utilizador como desativado.",
                        "Confirmar Remoção", 
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                    
                    if (opcao == JOptionPane.YES_OPTION) 
                    {
                        // Remover utilizador da BD
                        try 
                        {
                            Conexao_BD conexaoBD = new Conexao_BD();
                            Connection conn = conexaoBD.conexao();
                            
                            // 1. Descobrir o tipo do utilizador
                            String checkSql = "SELECT tipo, nome_utilizador, desativado FROM utilizador WHERE id_utilizador = ?";
                            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                            checkStmt.setInt(1, idUtilizador);
                            ResultSet rs = checkStmt.executeQuery();
                            
                            if (rs.next()) 
                            {
                                String tipo = rs.getString("tipo");
                                String nome = rs.getString("nome_utilizador");
                                boolean jaDesativado = rs.getBoolean("desativado");
                                
                                if (jaDesativado) 
                                {
                                    JOptionPane.showMessageDialog(janelaRemover, "Este utilizador já está desativado!");
                                    return;
                                }
                                
                                // 2. Desativar o utilizador
                                String updateSql = "UPDATE utilizador SET desativado = true WHERE id_utilizador = ?";
                                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                                updateStmt.setInt(1, idUtilizador);
                                
                                int linhasAfetadas = updateStmt.executeUpdate();
                                
                                if (linhasAfetadas > 0) 
                                {
                                    JOptionPane.showMessageDialog(janelaRemover, 
                                        tipo + " '" + nome + "' foi desativado com sucesso!",
                                        "Sucesso", 
                                        JOptionPane.INFORMATION_MESSAGE);
                                    
                                    // Limpar campos
                                    campoIdUtilizador.setText("");
                                    labelInfo.setText(" ");
                                    
                                    System.out.println("\n" + tipo + " " + nome + " desativado com sucesso da base de dados!");
                                } 
                                else 
                                {
                                    JOptionPane.showMessageDialog(janelaRemover, "Erro ao desativar utilizador!");
                                }
                                
                                updateStmt.close();
                            } 
                            else 
                            {
                                JOptionPane.showMessageDialog(janelaRemover, "Utilizador com ID " + idUtilizador + " não encontrado!");
                            }
                            
                            checkStmt.close();
                            rs.close();
                            conn.close();
                            
                        } 
                        catch (SQLException ex) 
                        {
                            JOptionPane.showMessageDialog(janelaRemover, "Erro ao remover utilizador: " + ex.getMessage());
                            System.out.println("Erro ao remover utilizador: " + ex.getMessage());
                        }
                    }
                    
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(janelaRemover, "ID deve ser um número válido!");
                }
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 4;
        janelaRemover.add(botaoRemover, gbc);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaRemover.dispose();
            }
        });
        gbc.gridx = 1;
        janelaRemover.add(botaoCancelar, gbc);
        
        janelaRemover.setVisible(true);
    }

    /**
     *  Método para abrir uma janela de busca de utilizador.
     *  Esta janela permite ao gestor buscar um utilizador pelo username e exibir suas informações.
     *  Se o utilizador estiver ativo, suas informações são exibidas; caso contrário, uma mensagem apropriada é mostrada.
     *
     * @author Guilherme Rodrigues
     */
    private void abrirJanelaBuscaUtilizador() 
    {
        JFrame janelaRemover = new JFrame("Visualizar Utilizador por Username");
        janelaRemover.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaRemover.setSize(700, 450);
        janelaRemover.setLocationRelativeTo(this);
        janelaRemover.setLayout(new GridBagLayout());
        janelaRemover.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Visualizar Utilizador", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaRemover.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo Username
        JLabel labelUsername = new JLabel("Username do Utilizador:");
        labelUsername.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaRemover.add(labelUsername, gbc);

        JTextField campoUsername = new JTextField();
        campoUsername.setPreferredSize(new Dimension(250, 35));
        campoUsername.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRemover.add(campoUsername, gbc);

        // Tabela
        String[] colunas = {"Nome", "Username", "Email", "Tipo", "Estado"};
        DefaultTableModel model = new DefaultTableModel(colunas, 0);
        JTable tabela = new JTable(model);
        tabela.setFillsViewportHeight(true);
        tabela.setFont(new Font("Arial", Font.PLAIN, 12));
        tabela.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));

        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setPreferredSize(new Dimension(650, 200));
        scrollPane.setBorder(BorderFactory.createTitledBorder("Resultado"));

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 10, 15);
        janelaRemover.add(scrollPane, gbc);

        // Reset
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // Botão Buscar
        JButton botaoBuscar = new JButton("Buscar Utilizador");
        botaoBuscar.setPreferredSize(new Dimension(200, 40));
        botaoBuscar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoBuscar.setBackground(new Color(70, 130, 180));
        botaoBuscar.setForeground(Color.WHITE);
        botaoBuscar.addActionListener(e -> {
            model.setRowCount(0); // limpa resultados anteriores
            String username = campoUsername.getText().trim();

            if (username.isEmpty()) {
                JOptionPane.showMessageDialog(janelaRemover, "Por favor, insira o username do utilizador!");
                return;
            }

            try {
                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();

                String sql = "SELECT nome_utilizador, username_utilizador, email_utilizador, tipo, desativado FROM utilizador WHERE username_utilizador = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, username);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    String nome = rs.getString("nome_utilizador");
                    String email = rs.getString("email_utilizador");
                    String tipo = rs.getString("tipo");
                    boolean desativado = rs.getBoolean("desativado");
                    String estado = desativado ? "DESATIVADO" : "ATIVO";

                    model.addRow(new Object[]{nome, username, email, tipo, estado});
                } else {
                    JOptionPane.showMessageDialog(janelaRemover, "Utilizador não encontrado!");
                }

                rs.close();
                pstmt.close();
                conn.close();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(janelaRemover, "Erro ao buscar utilizador: " + ex.getMessage());
                System.out.println("Erro SQL: " + ex.getMessage());
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.insets = new Insets(15, 15, 10, 15);
        janelaRemover.add(botaoBuscar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaRemover.dispose());
        gbc.gridx = 1;
        janelaRemover.add(botaoCancelar, gbc);

        janelaRemover.setVisible(true);
    }

    /**
     * Método para abrir uma janela de busca de utilizador.
     * Esta janela permite ao gestor buscar um utilizador pelo username e exibir suas informações.
     * Se o utilizador estiver ativo, suas informações são exibidas; caso contrário, uma mensagem apropriada é mostrada.
     *
     * @author Guilherme Rodrigues
     */
    private void abrirJanelaBuscaTipo() 
    {
        JFrame janelaRemover = new JFrame("Visualizar Utilizador por Tipo");
        janelaRemover.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaRemover.setSize(700, 500);
        janelaRemover.setLocationRelativeTo(this);
        janelaRemover.setLayout(new GridBagLayout());
        janelaRemover.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Visualizar Utilizador por Tipo", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaRemover.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo Tipo do Utilizador
        JLabel labelTipo = new JLabel("Tipo do Utilizador:");
        labelTipo.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaRemover.add(labelTipo, gbc);

        String[] tipos = {"Gestor", "Tecnico", "Fabricante"};
        JComboBox<String> comboTipo = new JComboBox<>(tipos);
        comboTipo.setPreferredSize(new Dimension(250, 35));
        comboTipo.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRemover.add(comboTipo, gbc);

        // Tabela para exibir resultados
        String[] colunas = {"Nome", "Username", "Email", "Tipo", "Estado"};
        DefaultTableModel model = new DefaultTableModel(colunas, 0);
        JTable tabela = new JTable(model);
        tabela.setFillsViewportHeight(true);
        tabela.setFont(new Font("Arial", Font.PLAIN, 12));
        tabela.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));

        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setPreferredSize(new Dimension(650, 250));
        scrollPane.setBorder(BorderFactory.createTitledBorder("Resultados"));

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaRemover.add(scrollPane, gbc);

        // Resetar configurações
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // Botão Buscar Utilizador
        JButton botaoBuscar = new JButton("Buscar Utilizadores");
        botaoBuscar.setPreferredSize(new Dimension(200, 40));
        botaoBuscar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoBuscar.setBackground(new Color(70, 130, 180));
        botaoBuscar.setForeground(Color.WHITE);

        botaoBuscar.addActionListener(e -> {
            model.setRowCount(0); // Limpa a tabela

            String tipoSelecionado = (String) comboTipo.getSelectedItem();

            try 
            {
                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();
                
                String sql = "SELECT nome_utilizador, username_utilizador, email_utilizador, tipo, desativado FROM utilizador WHERE tipo = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, tipoSelecionado);
                ResultSet rs = pstmt.executeQuery();

                boolean encontrou = false;

                while (rs.next()) 
                {
                    encontrou = true;
                    String nome = rs.getString("nome_utilizador");
                    String username = rs.getString("username_utilizador");
                    String email = rs.getString("email_utilizador");
                    String tipo = rs.getString("tipo");
                    boolean desativado = rs.getBoolean("desativado");
                    String estado = desativado ? "DESATIVADO" : "ATIVO";

                    model.addRow(new Object[]{nome, username, email, tipo, estado});
                }

                if (!encontrou) 
                {
                    JOptionPane.showMessageDialog(janelaRemover, "Nenhum utilizador do tipo " + tipoSelecionado + " foi encontrado.");
                }

                rs.close();
                pstmt.close();
                conn.close();
            } 
            catch (SQLException ex) 
            {
                JOptionPane.showMessageDialog(janelaRemover, "Erro ao buscar utilizadores: " + ex.getMessage());
                System.out.println("Erro SQL: " + ex.getMessage());
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.insets = new Insets(15, 15, 10, 15);
        janelaRemover.add(botaoBuscar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaRemover.dispose());
        gbc.gridx = 1;
        janelaRemover.add(botaoCancelar, gbc);

        janelaRemover.setVisible(true);
    }

    /**
     * Método para abrir uma janela de busca de todos os utilizadores.
     * Esta janela permite ao gestor visualizar todos os utilizadores cadastrados no sistema.
     * As informações são exibidas em um JScrollPane para facilitar a visualização.
     *
     * @author Guilherme Rodrigues
     */
    private void abrirJanelaBuscaTodos() 
    {
        JFrame janelaRemover = new JFrame("Visualizar Utilizador");
        janelaRemover.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaRemover.setSize(700, 500);
        janelaRemover.setLocationRelativeTo(this);
        janelaRemover.setLayout(new GridBagLayout());
        janelaRemover.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Visualizar Utilizador", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaRemover.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Tabela com modelo
        String[] colunas = {"Nome", "Username", "Email", "Tipo", "Estado"};
        DefaultTableModel model = new DefaultTableModel(colunas, 0);
        JTable tabela = new JTable(model);
        tabela.setFillsViewportHeight(true);
        tabela.setFont(new Font("Arial", Font.PLAIN, 12));
        tabela.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setPreferredSize(new Dimension(650, 300));
        scrollPane.setBorder(BorderFactory.createTitledBorder("Lista de Utilizadores"));
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaRemover.add(scrollPane, gbc);

        // Reset GridBagConstraints
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // Botão Buscar Utilizadores
        JButton botaoBuscar = new JButton("Buscar Utilizadores");
        botaoBuscar.setPreferredSize(new Dimension(200, 40));
        botaoBuscar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoBuscar.setBackground(new Color(70, 130, 180));
        botaoBuscar.setForeground(Color.WHITE);

        botaoBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) 
            {
                model.setRowCount(0); // limpa a tabela antes de adicionar novos dados

                try 
                {
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    
                    String sql = "SELECT nome_utilizador, username_utilizador, email_utilizador, tipo, desativado FROM utilizador";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    ResultSet rs = pstmt.executeQuery();

                    while (rs.next()) 
                    {
                        String nome = rs.getString("nome_utilizador");
                        String username = rs.getString("username_utilizador");
                        String email = rs.getString("email_utilizador");
                        String tipo = rs.getString("tipo");
                        boolean desativado = rs.getBoolean("desativado");
                        String estado = desativado ? "DESATIVADO" : "ATIVO";

                        model.addRow(new Object[]{nome, username, email, tipo, estado});
                    }

                    rs.close();
                    pstmt.close();
                    conn.close();
                } 
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(janelaRemover, "Erro ao buscar utilizadores: " + ex.getMessage());
                    System.out.println("Erro SQL: " + ex.getMessage());
                }
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(15, 15, 10, 15);
        janelaRemover.add(botaoBuscar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaRemover.dispose());
        gbc.gridx = 1;
        janelaRemover.add(botaoCancelar, gbc);

        janelaRemover.setVisible(true);
    }

    /**
     * Método para abrir uma janela de atualização de utilizador.
     * Esta janela permite ao gestor atualizar os dados de um utilizador específico.
     * O gestor pode buscar o utilizador pelo ID e escolher qual campo deseja atualizar.
     *
     * @author Guilherme Rodrigues
     */
   private void abrirJanelaAtualizarUtilizador() 
   {
        JFrame janelaAtualizar = new JFrame("Atualizar Utilizador");
        janelaAtualizar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaAtualizar.setSize(700, 600);
        janelaAtualizar.setLocationRelativeTo(this);
        janelaAtualizar.setLayout(new GridBagLayout());
        janelaAtualizar.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Atualizar Utilizador", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaAtualizar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo ID do Utilizador
        JLabel labelId = new JLabel("ID do Utilizador:");
        labelId.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaAtualizar.add(labelId, gbc);

        JTextField campoId = new JTextField();
        campoId.setPreferredSize(new Dimension(200, 30));
        campoId.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaAtualizar.add(campoId, gbc);

        // Tabela para mostrar dados atuais do utilizador
        String[] colunas = {"Campo", "Valor"};
        DefaultTableModel model = new DefaultTableModel(colunas, 0);
        JTable tabelaDados = new JTable(model);
        tabelaDados.setFont(new Font("Arial", Font.PLAIN, 12));
        tabelaDados.setRowHeight(25);
        tabelaDados.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        
        JScrollPane scrollDados = new JScrollPane(tabelaDados);
        scrollDados.setPreferredSize(new Dimension(600, 150));
        scrollDados.setBorder(BorderFactory.createTitledBorder("Dados Atuais"));

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 0.3;
        janelaAtualizar.add(scrollDados, gbc);

        // Reset
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        JLabel labelCampo = new JLabel("Campo a Atualizar:");
        labelCampo.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 3;
        janelaAtualizar.add(labelCampo, gbc);

        JComboBox<String> comboCampos = new JComboBox<>();
        comboCampos.setPreferredSize(new Dimension(200, 30));
        comboCampos.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaAtualizar.add(comboCampos, gbc);

        JLabel labelNovoValor = new JLabel("Novo Valor:");
        labelNovoValor.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 4;
        janelaAtualizar.add(labelNovoValor, gbc);

        JTextField campoNovoValor = new JTextField();
        campoNovoValor.setPreferredSize(new Dimension(200, 30));
        campoNovoValor.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaAtualizar.add(campoNovoValor, gbc);

        JCheckBox checkBoxValor = new JCheckBox();
        checkBoxValor.setFont(new Font("Arial", Font.PLAIN, 12));
        checkBoxValor.setBackground(Color.LIGHT_GRAY);
        checkBoxValor.setVisible(false);
        gbc.gridx = 1;
        gbc.gridy = 4;
        janelaAtualizar.add(checkBoxValor, gbc);

        JButton botaoBuscar = new JButton("Buscar Dados");
        botaoBuscar.setPreferredSize(new Dimension(150, 40));
        botaoBuscar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoBuscar.setBackground(new Color(70, 130, 180));
        botaoBuscar.setForeground(Color.WHITE);
        botaoBuscar.addActionListener(e -> {
            String idText = campoId.getText().trim();
            if (idText.isEmpty()) 
            {
                JOptionPane.showMessageDialog(janelaAtualizar, "Por favor, insira o ID do utilizador.");
                return;
            }
            try 
            {
                int id_utilizador = Integer.parseInt(idText);
                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();

                String checkSql = "SELECT * FROM utilizador WHERE id_utilizador = ?";
                PreparedStatement stmt = conn.prepareStatement(checkSql);
                stmt.setInt(1, id_utilizador);
                ResultSet rs = stmt.executeQuery();

                if (!rs.next()) 
                {
                    JOptionPane.showMessageDialog(janelaAtualizar, "Utilizador com ID " + id_utilizador + " não encontrado.");
                    return;
                }

                model.setRowCount(0); // limpar a tabela
                model.addRow(new Object[]{"ID", rs.getInt("id_utilizador")});
                model.addRow(new Object[]{"Nome", rs.getString("nome_utilizador")});
                model.addRow(new Object[]{"Username", rs.getString("username_utilizador")});
                model.addRow(new Object[]{"Email", rs.getString("email_utilizador")});
                model.addRow(new Object[]{"Tipo", rs.getString("tipo")});
                model.addRow(new Object[]{"Status", rs.getBoolean("desativado") ? "DESATIVADO" : "ATIVO"});

                comboCampos.removeAllItems();
                String tipo = rs.getString("tipo");

                comboCampos.addItem("Nome");
                comboCampos.addItem("Username");
                comboCampos.addItem("Email");
                comboCampos.addItem("Password");
                comboCampos.addItem("Estado");
                comboCampos.addItem("Desativado");

                if ("Tecnico".equalsIgnoreCase(tipo)) 
                {
                    comboCampos.addItem("NIF");
                    comboCampos.addItem("Telefone");
                    comboCampos.addItem("Morada");
                    comboCampos.addItem("Nivel de Certificacao");
                    comboCampos.addItem("Area de Especializacao");
                } 
                else if ("Fabricante".equalsIgnoreCase(tipo)) 
                {
                    comboCampos.addItem("NIF");
                    comboCampos.addItem("Telefone");
                    comboCampos.addItem("Morada");
                    comboCampos.addItem("Setor Comercial");
                    comboCampos.addItem("Inicio de atividade");
                }

                rs.close();
                stmt.close();
                conn.close();

            } 
            catch (Exception ex) 
            {
                JOptionPane.showMessageDialog(janelaAtualizar, "Erro: " + ex.getMessage());
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.insets = new Insets(20, 15, 10, 15);
        janelaAtualizar.add(botaoBuscar, gbc);

        comboCampos.addActionListener(e -> {
            String campo = (String) comboCampos.getSelectedItem();
            boolean isBoolean = campo != null && (campo.equals("Estado") || campo.equals("Desativado"));
            campoNovoValor.setVisible(!isBoolean);
            checkBoxValor.setVisible(isBoolean);
        });

        JButton botaoAtualizar = new JButton("Atualizar");
        botaoAtualizar.setPreferredSize(new Dimension(150, 40));
        botaoAtualizar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoAtualizar.setBackground(new Color(34, 139, 34));
        botaoAtualizar.setForeground(Color.WHITE);

        botaoAtualizar.addActionListener(e -> {
            String idText = campoId.getText().trim();
            String campoSelecionado = (String) comboCampos.getSelectedItem();

            if (idText.isEmpty() || campoSelecionado == null)
            {
                JOptionPane.showMessageDialog(janelaAtualizar, "Preencha todos os campos obrigatórios.");
                return;
            }

            try 
            {
                int id_utilizador = Integer.parseInt(idText);
                String novoValor = "";
                boolean valorBoolean = false;

                if (campoSelecionado.equals("Estado") || campoSelecionado.equals("Desativado")) 
                {
                    valorBoolean = checkBoxValor.isSelected();
                } 
                else 
                {
                    novoValor = campoNovoValor.getText().trim();
                    if (novoValor.isEmpty()) 
                    {
                        JOptionPane.showMessageDialog(janelaAtualizar, "Digite o novo valor.");
                        return;
                    }
                    if (campoSelecionado.equals("Telefone") && !novoValor.matches("[923]\\d{8}")) 
                    {
                        JOptionPane.showMessageDialog(janelaAtualizar, "Telefone inválido. Deve ter 9 dígitos e começar por 9, 2 ou 3.");
                        return;
                    }
                    if (campoSelecionado.equals("NIF") && !novoValor.matches("\\d{9}"))
                    {
                        JOptionPane.showMessageDialog(janelaAtualizar, "NIF inválido! Deve conter 9 dígitos.");
                        return;
                    }
                }

                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();

                PreparedStatement tipoStmt = conn.prepareStatement("SELECT tipo FROM utilizador WHERE id_utilizador = ?");
                tipoStmt.setInt(1, id_utilizador);
                ResultSet tipoRs = tipoStmt.executeQuery();

                if (tipoRs.next()) 
                {
                    String tipo = tipoRs.getString("tipo");
                    String campoBD = obterNomeCampo(campoSelecionado, tipo);

                    if (campoSelecionado.equals("Estado") || campoSelecionado.equals("Desativado")) 
                    {
                        String valorString = String.valueOf(valorBoolean);
                        atualizarUtilizador(id_utilizador, campoBD, valorString);
                        if (campoSelecionado.equals("Desativado"))
                        {
                            atualizarUtilizador(id_utilizador, "estado_utilizador", valorBoolean ? "false" : "true");
                        }
                    } 
                    else 
                    {
                        if (campoSelecionado.equals("Nome") || campoSelecionado.equals("Username") ||campoSelecionado.equals("Email") || campoSelecionado.equals("Password")) 
                        {
                            atualizarUtilizador(id_utilizador, campoBD, novoValor);
                        } 
                        else 
                        {
                            atualizarEspecializado(id_utilizador, campoBD, novoValor, tipo);
                        }
                    }

                    JOptionPane.showMessageDialog(janelaAtualizar, "Utilizador atualizado com sucesso!");
                    campoId.setText("");
                    campoNovoValor.setText("");
                    checkBoxValor.setSelected(false);
                    comboCampos.removeAllItems();
                    model.setRowCount(0);
                }

                tipoRs.close();
                tipoStmt.close();
                conn.close();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(janelaAtualizar, "Erro ao atualizar: " + ex.getMessage());
            }
        });

        gbc.gridx = 1;
        janelaAtualizar.add(botaoAtualizar, gbc);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(150, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaAtualizar.dispose());

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        janelaAtualizar.add(botaoCancelar, gbc);

        janelaAtualizar.setVisible(true);
    }

    /**
     *  Método para atualizar um utilizador na tabela principal.
     *  Este método recebe o ID do utilizador, o campo a ser atualizado e o novo valor.
     *  Ele executa uma atualização na tabela 'utilizador' com base nos parâmetros fornecidos.
     *  Se o campo for booleano, converte o novo valor para boolean antes de atualizar.
     * 
     *  @author Guilherme Rodrigues
     * 
     * @param id_utilizador
     * @param campo
     * @param novoValor
     */
    private void atualizarUtilizador(int id_utilizador, String campo, String novoValor) 
    {
        try 
        {
            Conexao_BD conexaoBD = new Conexao_BD();
            Connection conn = conexaoBD.conexao();
            
            String sql = "UPDATE utilizador SET " + campo + " = ? WHERE id_utilizador = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            
            // Verificar se é campo boolean
            if (campo.equals("estado_utilizador") || campo.equals("desativado")) 
            {
                boolean valorBoolean = Boolean.parseBoolean(novoValor);
                pstmt.setBoolean(1, valorBoolean);
            } 
            else 
            {
                pstmt.setString(1, novoValor);
            }
            
            pstmt.setInt(2, id_utilizador);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) 
            {
                System.out.println("Campo " + campo + " atualizado com sucesso!");
            } 
            else 
            {
                System.out.println("Nenhuma linha foi atualizada.");
            }
            
            pstmt.close();
            conn.close();
            
        } 
        catch (SQLException e) 
        {
            System.out.println("Erro ao atualizar utilizador: " + e.getMessage());
            throw new RuntimeException("Erro na atualização: " + e.getMessage());
        }
    }

    /**
     *  Método para atualizar um utilizador na tabela especializada.
     *  Este método recebe o ID do utilizador, o campo a ser atualizado e o novo valor.
     *  Ele executa uma atualização na tabela 'tecnico' ou 'fabricante' com base nos parâmetros fornecidos.
     *  Ele também verifica o tipo de utilizador para determinar a tabela correta.
     *
     *  @author Guilherme Rodrigues
     * 
     * @param id_utilizador
     * @param campo
     * @param novoValor
     * @param tipo
     */
    private void atualizarEspecializado(int id_utilizador, String campo, String novoValor, String tipo) 
    {
        try 
        {
            Conexao_BD conexaoBD = new Conexao_BD();
            Connection conn = conexaoBD.conexao();
            
            String tabela = "";
            if ("Tecnico".equalsIgnoreCase(tipo)) 
            {
                tabela = "tecnico";
            } 
            else if ("Fabricante".equalsIgnoreCase(tipo)) 
            {
                tabela = "fabricante";
            } 
            else 
            {
                throw new IllegalArgumentException("Tipo de utilizador inválido: " + tipo);
            }
            
            String sql = "UPDATE " + tabela + " SET " + campo + " = ? WHERE id_utilizador = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, novoValor);
            pstmt.setInt(2, id_utilizador);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) 
            {
                System.out.println("Campo " + campo + " atualizado com sucesso na tabela " + tabela + "!");
            } 
            else 
            {
                System.out.println("Nenhuma linha foi atualizada na tabela " + tabela + ".");
            }
            
            pstmt.close();
            conn.close();
            
        } 
        catch (SQLException e) 
        {
            System.out.println("Erro ao atualizar " + tipo + ": " + e.getMessage());
            throw new RuntimeException("Erro na atualização: " + e.getMessage());
        }
    }

    /**
     *  Método para obter o nome do campo correspondente ao campo selecionado.
     *  Este método recebe o campo selecionado e o tipo de utilizador (Tecnico ou Fabricante)
     *  e retorna o nome do campo correspondente na tabela.
     *
     *  @author Guilherme Rodrigues
     *
     * @param campoSelecionado
     * @param tipo
     * @return
     */
    private String obterNomeCampo(String campoSelecionado, String tipo) 
    {
        switch (campoSelecionado) 
        {
            case "Nome":
                return "nome_utilizador";
            case "Username":
                return "username_utilizador";
            case "Email":
                return "email_utilizador";
            case "Estado":
                return "estado_utilizador";
            case "Desativado":
                return "desativado";
            case "NIF":
                return "Tecnico".equalsIgnoreCase(tipo) ? "nif_tecnico" : "nif_fabricante";
            case "Telefone":
                return "Tecnico".equalsIgnoreCase(tipo) ? "telefone_tecnico" : "telefone_fabricante";
            case "Morada":
                return "Tecnico".equalsIgnoreCase(tipo) ? "morada_tecnico" : "morada_fabricante";
            case "Nivel de Certificacao":
                return "nivel_certificacao_tecnico";
            case "Area de Especializacao":
                return "area_especializacao_tecnico";
            case "Setor Comercial":
                return "setor_comercial_fabricante";
            case "Inicio de atividade":
                return "inicio_atividade_fabricante";
            default:
                return "";
        }
    }

    /** Método para abrir a janela de inserção de licenca
     * Este método cria uma nova janela JFrame para inserir uma nova licença.
     * 
     * @author Guilherme Rodrigues
     * 
     */
    private void abrirJanelaInserirLicenca() 
    {
        JFrame janelaInserir = new JFrame("Inserir Licença");
        janelaInserir.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaInserir.setSize(600, 400);
        janelaInserir.setLocationRelativeTo(this);
        janelaInserir.setLayout(new GridBagLayout());
        janelaInserir.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Inserir Licença", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaInserir.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Label para licença
        JLabel labelLicenca = new JLabel("Nome da Licença:");
        labelLicenca.setFont(new Font("Arial", Font.BOLD, 14));
        labelLicenca.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        janelaInserir.add(labelLicenca, gbc);

        // Campo de texto para licença
        JTextField campoLicenca = new JTextField();
        campoLicenca.setFont(new Font("Arial", Font.PLAIN, 14));
        campoLicenca.setPreferredSize(new Dimension(400, 30));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 15, 20, 15);
        janelaInserir.add(campoLicenca, gbc);

        // Resetar configurações do GridBagConstraints
        gbc.gridwidth = 1;
        gbc.insets = new Insets(15, 15, 10, 15);

        // Botão Inserir
        JButton botaoInserir = new JButton("Inserir Licença");
        botaoInserir.setPreferredSize(new Dimension(200, 40));
        botaoInserir.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoInserir.setBackground(new Color(70, 130, 180));
        botaoInserir.setForeground(Color.WHITE);
        botaoInserir.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            { 
                String licenca = campoLicenca.getText().trim();
                
                if (licenca.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaInserir, "Por favor, insira o nome da licença.");
                    return;
                }
                
                String sql = "INSERT INTO licencas (nome_licenca) VALUES (?)";
                try 
                {
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, licenca);
                    stmt.executeUpdate();
                    
                    JOptionPane.showMessageDialog(janelaInserir, "Licença inserida com sucesso!");
                    campoLicenca.setText(""); // Limpar o campo após inserção
                    
                    stmt.close();
                    conn.close();
                } 
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(janelaInserir, "Erro ao inserir licença: " + ex.getMessage());
                    System.out.println("Erro SQL: " + ex.getMessage());
                }
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 3;
        janelaInserir.add(botaoInserir, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaInserir.dispose();
            }
        });
        gbc.gridx = 1;
        janelaInserir.add(botaoCancelar, gbc);
        
        janelaInserir.setVisible(true);
    }

    /** Método para abrir a janela de aceitar pedido de certificação
     * Este método cria uma nova janela JFrame para aceitar pedidos de certificação de equipamentos.
     * 
     * @author Guilherme Rodrigues
     * 
     */
    private void abrirJanelaAceitarPedidoCertificacao() 
    {
        JFrame janelaAceitar = new JFrame("Aceitar Pedido de Certificação");
        janelaAceitar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaAceitar.setSize(800, 600);
        janelaAceitar.setLocationRelativeTo(this);
        janelaAceitar.setLayout(new GridBagLayout());
        janelaAceitar.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Aceitar Pedido de Certificação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaAceitar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo ID do Equipamento
        JLabel labelId = new JLabel("ID do Equipamento:");
        labelId.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaAceitar.add(labelId, gbc);

        JTextField campoIdEquipamento = new JTextField();
        campoIdEquipamento.setPreferredSize(new Dimension(200, 30));
        campoIdEquipamento.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaAceitar.add(campoIdEquipamento, gbc);

        // Campo ID do Técnico
        JLabel labelIdTecnico = new JLabel("ID do Técnico:");
        labelIdTecnico.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        janelaAceitar.add(labelIdTecnico, gbc);

        JTextField campoIdTecnico = new JTextField();
        campoIdTecnico.setPreferredSize(new Dimension(200, 30));
        campoIdTecnico.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaAceitar.add(campoIdTecnico, gbc);

        // Tabela de técnicos disponíveis
        DefaultTableModel modeloTabela = new DefaultTableModel();
        modeloTabela.addColumn("ID");
        modeloTabela.addColumn("Nome");
        modeloTabela.addColumn("Nível");
        modeloTabela.addColumn("Status");

        JTable tabelaTecnicos = new JTable(modeloTabela);
        JScrollPane scrollPane = new JScrollPane(tabelaTecnicos);
        scrollPane.setPreferredSize(new Dimension(700, 200));
        scrollPane.setBorder(BorderFactory.createTitledBorder("Técnicos Disponíveis"));

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        janelaAceitar.add(scrollPane, gbc);

        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Botão Listar Técnicos
        JButton botaoListarTecnicos = new JButton("Listar Técnicos");
        botaoListarTecnicos.setPreferredSize(new Dimension(150, 40));
        botaoListarTecnicos.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoListarTecnicos.setBackground(new Color(60, 179, 113));
        botaoListarTecnicos.setForeground(Color.WHITE);
        botaoListarTecnicos.addActionListener(e -> {
            try 
            {
                modeloTabela.setRowCount(0); // limpar tabela antes de preencher

                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();

                String sql = "SELECT u.id_utilizador, u.nome_utilizador, t.nivel_certificacao, t.escolhido_certificacao " +
                            "FROM utilizador u JOIN tecnico t ON u.id_utilizador = t.id_utilizador " +
                            "WHERE u.tipo = 'Tecnico' AND (t.escolhido_certificacao IS NULL OR t.escolhido_certificacao <> 'Negado pelo Tecnico')";
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) 
                {
                    String id = rs.getString("id_utilizador");
                    String nome = rs.getString("nome_utilizador");
                    String nivel = rs.getString("nivel_certificacao");
                    String status = rs.getString("escolhido_certificacao");
                    String estadoFinal = "DISPONÍVEL";
                    if ("Escolhido".equalsIgnoreCase(status)) 
                    {
                        estadoFinal = "OCUPADO";
                    }
                    modeloTabela.addRow(new Object[]{id, nome, nivel, estadoFinal});
                }

                rs.close();
                stmt.close();
                conn.close();
            } 
            catch (SQLException ex) 
            {
                JOptionPane.showMessageDialog(janelaAceitar, "Erro ao listar técnicos: " + ex.getMessage());
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 4;
        janelaAceitar.add(botaoListarTecnicos, gbc);

        // Botão Aceitar
        JButton botaoAceitar = new JButton("Aceitar Pedido");
        botaoAceitar.setPreferredSize(new Dimension(150, 40));
        botaoAceitar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoAceitar.setBackground(new Color(34, 139, 34));
        botaoAceitar.setForeground(Color.WHITE);
        botaoAceitar.addActionListener(e -> {
            try 
            {
                int idEquip = Integer.parseInt(campoIdEquipamento.getText().trim());
                int idTecnico = Integer.parseInt(campoIdTecnico.getText().trim());

                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();

                String sqlVerificar = "SELECT submetido_certificacao FROM equipamento WHERE id_equipamento = ?";
                PreparedStatement checkStmt = conn.prepareStatement(sqlVerificar);
                checkStmt.setInt(1, idEquip);
                ResultSet rs = checkStmt.executeQuery();

                if (rs.next() && "Submetido".equalsIgnoreCase(rs.getString("submetido_certificacao"))) 
                {
                    String updateEquip = "UPDATE equipamento SET submetido_certificacao = 'Aceite' WHERE id_equipamento = ?";
                    String updateTecnico = "UPDATE tecnico SET escolhido_certificacao = 'Escolhido' WHERE id_utilizador = ?";

                    PreparedStatement stmtEquip = conn.prepareStatement(updateEquip);
                    stmtEquip.setInt(1, idEquip);
                    stmtEquip.executeUpdate();

                    PreparedStatement stmtTec = conn.prepareStatement(updateTecnico);
                    stmtTec.setInt(1, idTecnico);
                    stmtTec.executeUpdate();

                    JOptionPane.showMessageDialog(janelaAceitar, "Pedido aceite com sucesso!");

                    campoIdEquipamento.setText("");
                    campoIdTecnico.setText("");
                    modeloTabela.setRowCount(0);

                    stmtEquip.close();
                    stmtTec.close();
                } 
                else 
                {
                    JOptionPane.showMessageDialog(janelaAceitar, "Equipamento não está submetido ou não existe.");
                }

                rs.close();
                checkStmt.close();
                conn.close();
            } 
            catch (Exception ex) 
            {
                JOptionPane.showMessageDialog(janelaAceitar, "Erro ao aceitar: " + ex.getMessage());
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 5;
        janelaAceitar.add(botaoAceitar, gbc);

        // Botão Negar
        JButton botaoNegar = new JButton("Negar Pedido");
        botaoNegar.setPreferredSize(new Dimension(150, 40));
        botaoNegar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoNegar.setBackground(new Color(220, 20, 60));
        botaoNegar.setForeground(Color.WHITE);
        botaoNegar.addActionListener(e -> {
            try 
            {
                int idEquip = Integer.parseInt(campoIdEquipamento.getText().trim());
                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();

                String update = "UPDATE equipamento SET submetido_certificacao = 'Negado' WHERE id_equipamento = ?";
                PreparedStatement pstmt = conn.prepareStatement(update);
                pstmt.setInt(1, idEquip);

                int res = pstmt.executeUpdate();
                if (res > 0) 
                {
                    JOptionPane.showMessageDialog(janelaAceitar, "Pedido negado com sucesso!");
                    campoIdEquipamento.setText("");
                    campoIdTecnico.setText("");
                    modeloTabela.setRowCount(0);
                } 
                else 
                {
                    JOptionPane.showMessageDialog(janelaAceitar, "Equipamento não encontrado!");
                }

                pstmt.close();
                conn.close();
            } 
            catch (Exception ex) 
            {
                JOptionPane.showMessageDialog(janelaAceitar, "Erro ao negar pedido: " + ex.getMessage());
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 5;
        janelaAceitar.add(botaoNegar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaAceitar.dispose());

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        janelaAceitar.add(botaoCancelar, gbc);

        janelaAceitar.setVisible(true);
    }

    /** Método para abrir a janela de listar certificações
     * Este método cria uma nova janela JFrame para listar certificações de equipamentos.
     * 
     * @author Guilherme Rodrigues
     * 
     * @param tipo Tipo de certificação a ser listada (por exemplo, "Equipamento", "Técnico", etc.)
     */
   private void abrirJanelaListarCertificacoes(String tipo) 
   {
        JFrame janelaListar = new JFrame("Listar Certificações");
        janelaListar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaListar.setSize(800, 600);
        janelaListar.setLocationRelativeTo(this);
        janelaListar.setLayout(new GridBagLayout());
        janelaListar.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Listar Certificações", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaListar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        JLabel labelOrdenacao = new JLabel("Ordenar por:");
        labelOrdenacao.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaListar.add(labelOrdenacao, gbc);

        JComboBox<String> comboOrdenacao = new JComboBox<>();
        comboOrdenacao.addItem("Data de Realização");
        comboOrdenacao.addItem("Número de Certificação");
        comboOrdenacao.setPreferredSize(new Dimension(200, 30));
        comboOrdenacao.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaListar.add(comboOrdenacao, gbc);

        DefaultTableModel tableModel = new DefaultTableModel();
        JTable tabela = new JTable(tableModel);
        tableModel.addColumn("ID Certificação");
        tableModel.addColumn("ID Equipamento");
        tableModel.addColumn("Estado");
        tableModel.addColumn("Data de Realização");

        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setPreferredSize(new Dimension(750, 350));
        scrollPane.setBorder(BorderFactory.createTitledBorder("Resultados"));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaListar.add(scrollPane, gbc);

        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        JButton botaoListar = new JButton("Listar Certificações");
        botaoListar.setPreferredSize(new Dimension(200, 40));
        botaoListar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoListar.setBackground(new Color(70, 130, 180));
        botaoListar.setForeground(Color.WHITE);
        botaoListar.addActionListener(e -> {
            try 
            {
                String ordenacao = (String) comboOrdenacao.getSelectedItem();
                String sql;

                if (ordenacao.equals("Data de Realização")) 
                {
                    sql = "SELECT c.id_certificacao, e.id_equipamento, c.estado, c.data_realizacao FROM certificacao c JOIN equipamento e ON c.id_certificacao = e.id_certificacao ORDER BY c.data_realizacao";
                } 
                else 
                {
                    sql = "SELECT c.id_certificacao, e.id_equipamento, c.estado, c.data_realizacao FROM certificacao c JOIN equipamento e ON c.id_certificacao = e.id_certificacao ORDER BY c.id_certificacao";
                }

                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();
                PreparedStatement pstmt = conn.prepareStatement(sql);
                ResultSet rs = pstmt.executeQuery();

                tableModel.setRowCount(0); // limpar tabela
                while (rs.next()) 
                {
                    int idCert = rs.getInt("id_certificacao");
                    int idEquip = rs.getInt("id_equipamento");
                    String estado = rs.getString("estado");
                    String data = rs.getString("data_realizacao") != null ? rs.getString("data_realizacao") : "N/A";
                    tableModel.addRow(new Object[]{idCert, idEquip, estado, data});
                }

                rs.close();
                pstmt.close();
                conn.close();

            } 
            catch (SQLException ex) 
            {
                JOptionPane.showMessageDialog(janelaListar, "Erro ao listar certificações: " + ex.getMessage());
                System.out.println("Erro SQL: " + ex.getMessage());
            }
        });
        gbc.gridy = 3;
        gbc.gridx = 0;
        janelaListar.add(botaoListar, gbc);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaListar.dispose());
        gbc.gridx = 1;
        janelaListar.add(botaoCancelar, gbc);

        janelaListar.setVisible(true);
    }

    /** Método para abrir a janela de pesquisar certificação
     * Este método cria uma nova janela JFrame para pesquisar certificações de equipamentos.
     * 
     * @author Guilherme Rodrigues
     * 
     */
    private void abrirJanelaPesquisarCertificacao() 
    {
        JFrame janelaPesquisar = new JFrame("Pesquisar Certificação");
        janelaPesquisar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaPesquisar.setSize(700, 600);
        janelaPesquisar.setLocationRelativeTo(this);
        janelaPesquisar.setLayout(new GridBagLayout());
        janelaPesquisar.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Pesquisar Certificação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.ipady = 15;
        janelaPesquisar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Checkbox para certificações não terminadas
        JCheckBox checkNaoTerminadas = new JCheckBox("Pesquisar apenas certificações não terminadas");
        checkNaoTerminadas.setFont(new Font("Arial", Font.PLAIN, 14));
        checkNaoTerminadas.setBackground(Color.LIGHT_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        janelaPesquisar.add(checkNaoTerminadas, gbc);
        gbc.gridwidth = 1;

        // Painel para critérios de pesquisa
        JPanel painelCriterios = new JPanel(new GridBagLayout());
        painelCriterios.setBackground(Color.LIGHT_GRAY);
        painelCriterios.setBorder(BorderFactory.createTitledBorder("Critérios de Pesquisa"));
        
        GridBagConstraints gbcCriterios = new GridBagConstraints();
        gbcCriterios.insets = new Insets(5, 10, 5, 10);
        gbcCriterios.fill = GridBagConstraints.HORIZONTAL;

        // ComboBox para tipo de pesquisa
        JLabel labelTipoPesquisa = new JLabel("Pesquisar por:");
        labelTipoPesquisa.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 0;
        painelCriterios.add(labelTipoPesquisa, gbcCriterios);

        String[] tiposPesquisa = {"Todos", "Estado", "Número", "Fabricante", "Período Temporal"};
        JComboBox<String> comboTipoPesquisa = new JComboBox<>(tiposPesquisa);
        comboTipoPesquisa.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 1;
        gbcCriterios.gridwidth = 2;
        painelCriterios.add(comboTipoPesquisa, gbcCriterios);
        gbcCriterios.gridwidth = 1;

        // Campo Estado
        JLabel labelEstado = new JLabel("Estado:");
        labelEstado.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 1;
        painelCriterios.add(labelEstado, gbcCriterios);

        JTextField campoEstado = new JTextField(20);
        campoEstado.setFont(new Font("Arial", Font.PLAIN, 14));
        campoEstado.setEnabled(false);
        gbcCriterios.gridx = 1;
        gbcCriterios.gridwidth = 2;
        painelCriterios.add(campoEstado, gbcCriterios);
        gbcCriterios.gridwidth = 1;

        // Campo Número
        JLabel labelNumero = new JLabel("Número:");
        labelNumero.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 2;
        painelCriterios.add(labelNumero, gbcCriterios);

        JTextField campoNumero = new JTextField(20);
        campoNumero.setFont(new Font("Arial", Font.PLAIN, 14));
        campoNumero.setEnabled(false);
        gbcCriterios.gridx = 1;
        gbcCriterios.gridwidth = 2;
        painelCriterios.add(campoNumero, gbcCriterios);
        gbcCriterios.gridwidth = 1;

        // Campo Fabricante
        JLabel labelFabricante = new JLabel("ID Fabricante:");
        labelFabricante.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 3;
        painelCriterios.add(labelFabricante, gbcCriterios);

        JTextField campoFabricante = new JTextField(20);
        campoFabricante.setFont(new Font("Arial", Font.PLAIN, 14));
        campoFabricante.setEnabled(false);
        gbcCriterios.gridx = 1;
        gbcCriterios.gridwidth = 2;
        painelCriterios.add(campoFabricante, gbcCriterios);
        gbcCriterios.gridwidth = 1;

        // Campos de Data
        JLabel labelDataInicio = new JLabel("Data Início:");
        labelDataInicio.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 4;
        painelCriterios.add(labelDataInicio, gbcCriterios);

        JTextField campoDataInicio = new JTextField("YYYY-MM-DD");
        campoDataInicio.setFont(new Font("Arial", Font.PLAIN, 14));
        campoDataInicio.setEnabled(false);
        gbcCriterios.gridx = 1;
        painelCriterios.add(campoDataInicio, gbcCriterios);

        JLabel labelDataFim = new JLabel("Data Fim:");
        labelDataFim.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 5;
        painelCriterios.add(labelDataFim, gbcCriterios);

        JTextField campoDataFim = new JTextField("YYYY-MM-DD");
        campoDataFim.setFont(new Font("Arial", Font.PLAIN, 14));
        campoDataFim.setEnabled(false);
        gbcCriterios.gridx = 1;
        painelCriterios.add(campoDataFim, gbcCriterios);

        // Adicionar o painel de critérios à janela principal
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        janelaPesquisar.add(painelCriterios, gbc);
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Label para mostrar resultados
        JLabel labelResultados = new JLabel(" ");
        labelResultados.setFont(new Font("Arial", Font.PLAIN, 14));
        labelResultados.setForeground(Color.BLUE);
        labelResultados.setVerticalAlignment(JLabel.TOP);
        
        // Criar JScrollPane para os resultados
        JScrollPane scrollPane = new JScrollPane(labelResultados);
        scrollPane.setPreferredSize(new Dimension(650, 200));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Resultados"));
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaPesquisar.add(scrollPane, gbc);
        
        // Resetar configurações do GridBagConstraints
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // Listener para habilitar/desabilitar campos baseado na seleção
        comboTipoPesquisa.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String selecao = (String) comboTipoPesquisa.getSelectedItem();
                
                // Desabilitar todos os campos primeiro
                campoEstado.setEnabled(false);
                campoNumero.setEnabled(false);
                campoFabricante.setEnabled(false);
                campoDataInicio.setEnabled(false);
                campoDataFim.setEnabled(false);
                
                // Habilitar campos baseado na seleção
                switch (selecao) 
                {
                    case "Estado":
                        campoEstado.setEnabled(true);
                        break;
                    case "Número":
                        campoNumero.setEnabled(true);
                        break;
                    case "Fabricante":
                        campoFabricante.setEnabled(true);
                        break;
                    case "Período Temporal":
                        campoDataInicio.setEnabled(true);
                        campoDataFim.setEnabled(true);
                        break;
                }
            }
        });

        // Botão Pesquisar
        JButton botaoPesquisar = new JButton("Pesquisar");
        botaoPesquisar.setPreferredSize(new Dimension(150, 40));
        botaoPesquisar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoPesquisar.setBackground(new Color(70, 130, 180));
        botaoPesquisar.setForeground(Color.WHITE);
        botaoPesquisar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                try 
                {
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    
                    String sql = "";
                    PreparedStatement pstmt = null;
                    String tipoPesquisa = (String) comboTipoPesquisa.getSelectedItem();
                    
                    if (checkNaoTerminadas.isSelected()) 
                    {
                        sql = "SELECT e.id_equipamento, c.id_certificacao, c.estado FROM equipamento e JOIN certificacao c ON e.id_certificacao = c.id_certificacao WHERE c.estado != 'Arquivado' AND c.estado != 'Finalizado'";
                        pstmt = conn.prepareStatement(sql);
                    } 
                    else 
                    {
                        switch (tipoPesquisa) 
                        {
                            case "Todos":
                                sql = "SELECT e.id_equipamento, c.id_certificacao, c.estado FROM equipamento e JOIN certificacao c ON e.id_certificacao = c.id_certificacao";
                                pstmt = conn.prepareStatement(sql);
                                break;
                            case "Estado":
                                if (campoEstado.getText().trim().isEmpty()) 
                                {
                                    JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira um estado para pesquisar.");
                                    return;
                                }
                                sql = "SELECT e.id_equipamento, c.id_certificacao, c.estado FROM equipamento e JOIN certificacao c ON e.id_certificacao = c.id_certificacao WHERE c.estado = ?";
                                pstmt = conn.prepareStatement(sql);
                                pstmt.setString(1, campoEstado.getText().trim());
                                break;
                            case "Número":
                                if (campoNumero.getText().trim().isEmpty()) 
                                {
                                    JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira um número para pesquisar.");
                                    return;
                                }
                                try 
                                {
                                    int numero = Integer.parseInt(campoNumero.getText().trim());
                                    sql = "SELECT c.id_certificacao, e.id_equipamento, c.estado FROM certificacao c JOIN equipamento e ON c.id_certificacao = e.id_certificacao WHERE c.id_certificacao = ?";
                                    pstmt = conn.prepareStatement(sql);
                                    pstmt.setInt(1, numero);
                                } 
                                catch (NumberFormatException ex) 
                                {
                                    JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira um número válido.");
                                    return;
                                }
                                break;
                            case "Fabricante":
                                if (campoFabricante.getText().trim().isEmpty()) 
                                {
                                    JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira o ID do fabricante para pesquisar.");
                                    return;
                                }
                                try 
                                {
                                    int fabricante = Integer.parseInt(campoFabricante.getText().trim());
                                    sql = "SELECT e.id_equipamento, c.id_certificacao, c.estado FROM equipamento e JOIN certificacao c ON e.id_certificacao = c.id_certificacao WHERE e.id_utilizador = ?";
                                    pstmt = conn.prepareStatement(sql);
                                    pstmt.setInt(1, fabricante);
                                } 
                                catch (NumberFormatException ex) 
                                {
                                    JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira um ID de fabricante válido.");
                                    return;
                                }
                                break;
                            case "Período Temporal":
                                if (campoDataInicio.getText().trim().isEmpty() || campoDataFim.getText().trim().isEmpty() ||
                                    campoDataInicio.getText().equals("YYYY-MM-DD") || campoDataFim.getText().equals("YYYY-MM-DD")) 
                                {
                                    JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira as datas de início e fim para pesquisar.");
                                    return;
                                }
                                sql = "SELECT e.id_equipamento, c.id_certificacao, c.estado FROM equipamento e JOIN certificacao c ON e.id_certificacao = c.id_certificacao WHERE c.data_realizacao BETWEEN ?::DATE AND ?::DATE";
                                pstmt = conn.prepareStatement(sql);
                                pstmt.setString(1, campoDataInicio.getText().trim());
                                pstmt.setString(2, campoDataFim.getText().trim());
                                break;
                        }
                    }
                    
                    ResultSet rs = pstmt.executeQuery();
                    
                    StringBuilder resultados = new StringBuilder();
                    resultados.append("<html><div style='text-align: center; padding: 10px;'>");
                    
                    boolean encontrouCertificacoes = false;
                    
                    while (rs.next()) 
                    {
                        encontrouCertificacoes = true;
                        int id_certificacao = rs.getInt("id_certificacao");
                        int id_equipamento = rs.getInt("id_equipamento");
                        String estado = rs.getString("estado");
                        
                        resultados.append("─────────────────────────<br>");
                        resultados.append("<b>ID Certificação:</b> ").append(id_certificacao).append("<br>");
                        resultados.append("<b>ID Equipamento:</b> ").append(id_equipamento).append("<br>");
                        resultados.append("<b>Estado:</b> ").append(estado).append("<br><br>");
                    }
                    
                    if (!encontrouCertificacoes) 
                    {
                        resultados.append("<span style='color: red;'><b>Nenhum pedido de certificação encontrado.</b></span><br>");
                    }
                    
                    resultados.append("</div></html>");
                    labelResultados.setText(resultados.toString());
                    
                    // Fazer scroll para o topo após carregar os dados
                    SwingUtilities.invokeLater(() -> {
                        scrollPane.getVerticalScrollBar().setValue(0);
                    });
                    
                    rs.close();
                    pstmt.close();
                    conn.close();
                    
                } 
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(janelaPesquisar, "Erro ao pesquisar certificações: " + ex.getMessage());
                    System.out.println("Erro SQL: " + ex.getMessage());
                }
            }
        });
        
        gbc.gridy = 4;
        gbc.insets = new Insets(15, 15, 10, 15);
        gbc.gridx = 0;
        janelaPesquisar.add(botaoPesquisar, gbc);

        // Botão Limpar
        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setPreferredSize(new Dimension(150, 40));
        botaoLimpar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoLimpar.setBackground(new Color(255, 140, 0));
        botaoLimpar.setForeground(Color.WHITE);
        botaoLimpar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                campoEstado.setText("");
                campoNumero.setText("");
                campoFabricante.setText("");
                campoDataInicio.setText("YYYY-MM-DD");
                campoDataFim.setText("YYYY-MM-DD");
                labelResultados.setText(" ");
                checkNaoTerminadas.setSelected(false);
                comboTipoPesquisa.setSelectedIndex(0);
            }
        });
        gbc.gridx = 1;
        janelaPesquisar.add(botaoLimpar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(150, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaPesquisar.dispose();
            }
        });
        gbc.gridx = 2;
        janelaPesquisar.add(botaoCancelar, gbc);
        
        janelaPesquisar.setVisible(true);
    }

    /** Método para abrir a janela de pesquisar equipamento
     * Este método cria uma nova janela JFrame para pesquisar equipamentos.
     * 
     * @author Guilherme Rodrigues
     * 
     * @param tipo Tipo de utilizador (por exemplo, "Gestor", "Técnico", etc.)
     * @param id_utilizador1 ID do utilizador que está pesquisando o equipamento
     */
    int id_utilizador1 = 0;
    private void abrirJanelaPesquisarEquipamento(String tipo, int id_utilizador1) 
    {
        JFrame janelaPesquisar = new JFrame("Pesquisar Equipamento");
        janelaPesquisar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaPesquisar.setSize(800, 700);
        janelaPesquisar.setLocationRelativeTo(this);
        janelaPesquisar.setLayout(new GridBagLayout());
        janelaPesquisar.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Pesquisar Equipamento", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.ipady = 15;
        janelaPesquisar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        JLabel labelTipoUtilizador = new JLabel("Tipo de Utilizador: " + tipo, JLabel.CENTER);
        labelTipoUtilizador.setFont(new Font("Arial", Font.ITALIC, 14));
        labelTipoUtilizador.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        janelaPesquisar.add(labelTipoUtilizador, gbc);
        gbc.gridwidth = 1;

        JPanel painelCriterios = new JPanel(new GridBagLayout());
        painelCriterios.setBackground(Color.LIGHT_GRAY);
        painelCriterios.setBorder(BorderFactory.createTitledBorder("Critérios de Pesquisa"));

        GridBagConstraints gbcCriterios = new GridBagConstraints();
        gbcCriterios.insets = new Insets(10, 15, 10, 15);
        gbcCriterios.fill = GridBagConstraints.HORIZONTAL;

        JLabel labelTipoPesquisa = new JLabel("Pesquisar por:");
        labelTipoPesquisa.setFont(new Font("Arial", Font.BOLD, 16));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 0;
        gbcCriterios.gridwidth = 2;
        painelCriterios.add(labelTipoPesquisa, gbcCriterios);
        gbcCriterios.gridwidth = 1;

        JRadioButton radioMarca = new JRadioButton("Marca");
        radioMarca.setFont(new Font("Arial", Font.PLAIN, 14));
        radioMarca.setBackground(Color.LIGHT_GRAY);
        radioMarca.setSelected(true);
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 1;
        painelCriterios.add(radioMarca, gbcCriterios);

        JRadioButton radioCodigo = new JRadioButton("Código (ID)");
        radioCodigo.setFont(new Font("Arial", Font.PLAIN, 14));
        radioCodigo.setBackground(Color.LIGHT_GRAY);
        gbcCriterios.gridx = 1;
        gbcCriterios.gridy = 1;
        painelCriterios.add(radioCodigo, gbcCriterios);

        ButtonGroup grupoRadio = new ButtonGroup();
        grupoRadio.add(radioMarca);
        grupoRadio.add(radioCodigo);

        JLabel labelMarca = new JLabel("Marca do Equipamento:");
        labelMarca.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 2;
        painelCriterios.add(labelMarca, gbcCriterios);

        JTextField campoMarca = new JTextField(25);
        campoMarca.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 1;
        gbcCriterios.gridy = 2;
        painelCriterios.add(campoMarca, gbcCriterios);

        JLabel labelCodigo = new JLabel("ID do Equipamento:");
        labelCodigo.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcCriterios.gridx = 0;
        gbcCriterios.gridy = 3;
        painelCriterios.add(labelCodigo, gbcCriterios);

        JTextField campoCodigo = new JTextField(25);
        campoCodigo.setFont(new Font("Arial", Font.PLAIN, 14));
        campoCodigo.setEnabled(false);
        gbcCriterios.gridx = 1;
        gbcCriterios.gridy = 3;
        painelCriterios.add(campoCodigo, gbcCriterios);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        janelaPesquisar.add(painelCriterios, gbc);
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        DefaultTableModel tableModel = new DefaultTableModel();
        JTable tabela = new JTable(tableModel);
        tableModel.addColumn("ID Equipamento");
        tableModel.addColumn("Marca");
        tableModel.addColumn("Modelo");
        tableModel.addColumn("Submetido");

        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setPreferredSize(new Dimension(750, 300));
        scrollPane.setBorder(BorderFactory.createTitledBorder("Resultados"));

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaPesquisar.add(scrollPane, gbc);

        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        radioMarca.addActionListener(e -> {
            campoMarca.setEnabled(true);
            campoCodigo.setEnabled(false);
            campoCodigo.setText("");
        });

        radioCodigo.addActionListener(e -> {
            campoMarca.setEnabled(false);
            campoCodigo.setEnabled(true);
            campoMarca.setText("");
        });

        JButton botaoPesquisar = new JButton("Pesquisar");
        botaoPesquisar.setPreferredSize(new Dimension(150, 40));
        botaoPesquisar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoPesquisar.setBackground(new Color(70, 130, 180));
        botaoPesquisar.setForeground(Color.WHITE);
        botaoPesquisar.addActionListener(e -> {
            try 
            {
                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();

                PreparedStatement pstmt;
                String sql;

                if (radioMarca.isSelected()) 
                {
                    if (campoMarca.getText().trim().isEmpty()) 
                    {
                        JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira a marca do equipamento.");
                        return;
                    }

                    if (tipo.equals("Gestor")) 
                    {
                        sql = "SELECT id_equipamento, marca_equipamento, modelo_equipamento, submetido_certificacao FROM equipamento WHERE marca_equipamento LIKE ?";
                        pstmt = conn.prepareStatement(sql);
                        pstmt.setString(1, "%" + campoMarca.getText().trim() + "%");
                    } 
                    else 
                    {
                        sql = "SELECT id_equipamento, marca_equipamento, modelo_equipamento, submetido_certificacao FROM equipamento WHERE marca_equipamento LIKE ? AND id_utilizador = ?";
                        pstmt = conn.prepareStatement(sql);
                        pstmt.setString(1, "%" + campoMarca.getText().trim() + "%");
                        pstmt.setInt(2, id_utilizador1);
                    }
                } 
                else 
                {
                    if (campoCodigo.getText().trim().isEmpty()) 
                    {
                        JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira o ID do equipamento.");
                        return;
                    }

                    int idEquip;
                    try 
                    {
                        idEquip = Integer.parseInt(campoCodigo.getText().trim());
                    } 
                    catch (NumberFormatException ex) 
                    {
                        JOptionPane.showMessageDialog(janelaPesquisar, "Por favor, insira um ID válido (apenas números).");
                        return;
                    }

                    if (tipo.equals("Gestor")) 
                    {
                        sql = "SELECT id_equipamento, marca_equipamento, modelo_equipamento, submetido_certificacao FROM equipamento WHERE id_equipamento = ?";
                        pstmt = conn.prepareStatement(sql);
                        pstmt.setInt(1, idEquip);
                    } 
                    else 
                    {
                        sql = "SELECT id_equipamento, marca_equipamento, modelo_equipamento, submetido_certificacao FROM equipamento WHERE id_equipamento = ? AND id_utilizador = ?";
                        pstmt = conn.prepareStatement(sql);
                        pstmt.setInt(1, idEquip);
                        pstmt.setInt(2, id_utilizador1);
                    }
                }

                ResultSet rs = pstmt.executeQuery();
                tableModel.setRowCount(0);

                while (rs.next()) 
                {
                    int id = rs.getInt("id_equipamento");
                    String marca = rs.getString("marca_equipamento");
                    String modelo = rs.getString("modelo_equipamento");
                    String status = rs.getString("submetido_certificacao").equals("true") ? "SIM" : "NÃO";
                    tableModel.addRow(new Object[]{id, marca, modelo, status});
                }

                rs.close();
                pstmt.close();
                conn.close();

            } 
            catch (SQLException ex) 
            {
                JOptionPane.showMessageDialog(janelaPesquisar, "Erro ao pesquisar equipamentos: " + ex.getMessage());
            }
        });
        gbc.gridy = 4;
        gbc.insets = new Insets(15, 15, 10, 15);
        gbc.gridx = 0;
        janelaPesquisar.add(botaoPesquisar, gbc);

        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setPreferredSize(new Dimension(150, 40));
        botaoLimpar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoLimpar.setBackground(new Color(255, 140, 0));
        botaoLimpar.setForeground(Color.WHITE);
        botaoLimpar.addActionListener(e -> {
            campoMarca.setText("");
            campoCodigo.setText("");
            tableModel.setRowCount(0);
            radioMarca.setSelected(true);
            campoMarca.setEnabled(true);
            campoCodigo.setEnabled(false);
        });
        gbc.gridx = 1;
        janelaPesquisar.add(botaoLimpar, gbc);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(150, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaPesquisar.dispose());
        gbc.gridx = 2;
        janelaPesquisar.add(botaoCancelar, gbc);

        janelaPesquisar.setVisible(true);
    }

    /** Método para abrir a janela de arquivar certificação
     * Este método cria uma nova janela JFrame para arquivar certificações.
     * 
     * @author Guilherme Rodrigues
     */
    private void abrirJanelaArquivarCertificacao() 
    {
        JFrame janelaArquivar = new JFrame("Arquivar Certificação");
        janelaArquivar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaArquivar.setSize(600, 500);
        janelaArquivar.setLocationRelativeTo(this);
        janelaArquivar.setLayout(new GridBagLayout());
        janelaArquivar.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Arquivar Certificação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaArquivar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo ID da Certificação
        JLabel labelId = new JLabel("ID da Certificação:");
        labelId.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaArquivar.add(labelId, gbc);

        JTextField campoId = new JTextField(20);
        campoId.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 1;
        janelaArquivar.add(campoId, gbc);

        // Label para mostrar informações
        JLabel labelInfo = new JLabel(" ");
        labelInfo.setFont(new Font("Arial", Font.PLAIN, 14));
        labelInfo.setForeground(Color.BLUE);
        labelInfo.setVerticalAlignment(JLabel.TOP);
        
        // Criar JScrollPane para o label
        JScrollPane scrollPane = new JScrollPane(labelInfo);
        scrollPane.setPreferredSize(new Dimension(550, 200));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Informações"));
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaArquivar.add(scrollPane, gbc);
        
        // Resetar configurações do GridBagConstraints
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // Botão Arquivar
        JButton botaoArquivar = new JButton("Arquivar Certificação");
        botaoArquivar.setPreferredSize(new Dimension(200, 40));
        botaoArquivar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoArquivar.setBackground(new Color(70, 130, 180));
        botaoArquivar.setForeground(Color.WHITE);
        botaoArquivar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                if (campoId.getText().trim().isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaArquivar, "Por favor, insira o ID da certificação.");
                    return;
                }
                
                try 
                {
                    int id_certificacao = Integer.parseInt(campoId.getText().trim());
                    
                    // Verificar se a certificação existe e está finalizada
                    String sql2 = "SELECT id_certificacao, estado FROM certificacao WHERE id_certificacao = ?";
                    
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    PreparedStatement stmt = conn.prepareStatement(sql2);
                    stmt.setInt(1, id_certificacao);
                    ResultSet rs = stmt.executeQuery();
                    
                    StringBuilder resultado = new StringBuilder();
                    resultado.append("<html><div style='text-align: center; padding: 10px;'>");
                    
                    if (!rs.next()) 
                    {
                        resultado.append("<span style='color: red; font-weight: bold;'>ERRO: Certificação não encontrada!</span><br>");
                        resultado.append("─────────────────────────<br>");
                        resultado.append("Verifique se o ID da certificação está correto.");
                    } 
                    else 
                    {
                        String estado = rs.getString("estado");
                        
                        if (!estado.equals("finalizado")) 
                        {
                            resultado.append("<span style='color: red; font-weight: bold;'>ERRO: Certificação não pode ser arquivada!</span><br>");
                            resultado.append("─────────────────────────<br>");
                            resultado.append("<b>ID:</b> ").append(id_certificacao).append("<br>");
                            resultado.append("<b>Estado Atual:</b> ").append(estado.toUpperCase()).append("<br>");
                            resultado.append("─────────────────────────<br>");
                            resultado.append("Somente certificações com estado 'finalizado' podem ser arquivadas.");
                        } 
                        else 
                        {
                            // Arquivar a certificação
                            String sql = "UPDATE certificacao SET estado = 'arquivado' WHERE id_certificacao = ?";
                            PreparedStatement stmtUpdate = conn.prepareStatement(sql);
                            stmtUpdate.setInt(1, id_certificacao);
                            int rowsAffected = stmtUpdate.executeUpdate();
                            
                            if (rowsAffected > 0) 
                            {
                                resultado.append("<span style='color: green; font-weight: bold;'>SUCESSO: Certificação arquivada!</span><br>");
                                resultado.append("─────────────────────────<br>");
                                resultado.append("<b>ID:</b> ").append(id_certificacao).append("<br>");
                                resultado.append("<b>Estado Anterior:</b> FINALIZADO<br>");
                                resultado.append("<b>Estado Atual:</b> ARQUIVADO<br>");
                                resultado.append("─────────────────────────<br>");
                                resultado.append("A certificação foi arquivada com sucesso!");
                            } 
                            else 
                            {
                                resultado.append("<span style='color: red; font-weight: bold;'>ERRO: Falha ao arquivar certificação!</span><br>");
                                resultado.append("─────────────────────────<br>");
                                resultado.append("Ocorreu um erro durante o processo de arquivamento.");
                            }
                            
                            stmtUpdate.close();
                        }
                    }
                    
                    resultado.append("</div></html>");
                    labelInfo.setText(resultado.toString());
                    
                    // Fazer scroll para o topo após carregar os dados
                    SwingUtilities.invokeLater(() -> {
                        scrollPane.getVerticalScrollBar().setValue(0);
                    });
                    
                    rs.close();
                    stmt.close();
                    conn.close();
                    
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(janelaArquivar, "Por favor, insira um ID válido (apenas números).");
                } 
                catch (SQLException ex) 
                {
                    StringBuilder resultado = new StringBuilder();
                    resultado.append("<html><div style='text-align: center; padding: 10px;'>");
                    resultado.append("<span style='color: red; font-weight: bold;'>ERRO DE CONEXÃO!</span><br>");
                    resultado.append("─────────────────────────<br>");
                    resultado.append("Erro ao conectar com a base de dados:<br>");
                    resultado.append(ex.getMessage());
                    resultado.append("</div></html>");
                    labelInfo.setText(resultado.toString());
                    
                    System.out.println("Erro SQL: " + ex.getMessage());
                }
            }
        });
        gbc.gridy = 3;
        gbc.insets = new Insets(15, 15, 10, 15);
        gbc.gridx = 0;
        janelaArquivar.add(botaoArquivar, gbc);

        // Botão Limpar
        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setPreferredSize(new Dimension(200, 40));
        botaoLimpar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoLimpar.setBackground(new Color(255, 140, 0));
        botaoLimpar.setForeground(Color.WHITE);
        botaoLimpar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                campoId.setText("");
                labelInfo.setText(" ");
            }
        });
        gbc.gridx = 1;
        janelaArquivar.add(botaoLimpar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaArquivar.dispose();
            }
        });
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        janelaArquivar.add(botaoCancelar, gbc);
        
        janelaArquivar.setVisible(true);
    }

    /** Método para listar notificações
     * Este método cria uma nova janela JFrame para listar notificações do sistema.
     * 
     * @author Guilherme Rodrigues
     */
    public static void listarNotificacoes() 
    {
        JFrame janelaNotificacoes = new JFrame("Sistema de Notificações");
        janelaNotificacoes.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaNotificacoes.setSize(700, 600);
        janelaNotificacoes.setLocationRelativeTo(null);
        janelaNotificacoes.setLayout(new GridBagLayout());
        janelaNotificacoes.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Sistema de Notificações", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        gbc.ipady = 15;
        janelaNotificacoes.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Label para mostrar informações das notificações
        JLabel labelInfo = new JLabel(" ");
        labelInfo.setFont(new Font("Arial", Font.PLAIN, 14));
        labelInfo.setForeground(Color.BLUE);
        labelInfo.setVerticalAlignment(JLabel.TOP);
        
        // Criar JScrollPane para o label
        JScrollPane scrollPane = new JScrollPane(labelInfo);
        scrollPane.setPreferredSize(new Dimension(650, 300));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Resultados"));
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaNotificacoes.add(scrollPane, gbc);
        
        // Resetar configurações do GridBagConstraints
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.insets = new Insets(10, 15, 10, 15);

        // Botão 1 - Utilizadores com pedido de registo
        JButton botaoRegistos = new JButton("Pedidos de Registo");
        botaoRegistos.setPreferredSize(new Dimension(150, 40));
        botaoRegistos.setFont(new Font("Arial", Font.PLAIN, 12));
        botaoRegistos.setBackground(new Color(70, 130, 180));
        botaoRegistos.setForeground(Color.WHITE);
        botaoRegistos.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                buscarUtilizadores(labelInfo, scrollPane, "SELECT * FROM utilizador WHERE estado_utilizador = false","Utilizadores com Pedido de Registo");
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 2;
        janelaNotificacoes.add(botaoRegistos, gbc);

        // Botão 2 - Utilizadores com pedido de remoção
        JButton botaoRemocoes = new JButton("Pedidos de Remoção");
        botaoRemocoes.setPreferredSize(new Dimension(150, 40));
        botaoRemocoes.setFont(new Font("Arial", Font.PLAIN, 12));
        botaoRemocoes.setBackground(new Color(220, 53, 69));
        botaoRemocoes.setForeground(Color.WHITE);
        botaoRemocoes.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                buscarUtilizadores(labelInfo, scrollPane,"SELECT * FROM utilizador WHERE pedido_remocao = true","Utilizadores com Pedido de Remoção");
            }
        });
        gbc.gridx = 1;
        janelaNotificacoes.add(botaoRemocoes, gbc);

        // Botão 3 - Equipamentos com pedido de certificação
        JButton botaoCertificacoes = new JButton("Certificações");
        botaoCertificacoes.setPreferredSize(new Dimension(150, 40));
        botaoCertificacoes.setFont(new Font("Arial", Font.PLAIN, 12));
        botaoCertificacoes.setBackground(new Color(40, 167, 69));
        botaoCertificacoes.setForeground(Color.WHITE);
        botaoCertificacoes.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                buscarEquipamentos(labelInfo, scrollPane,"SELECT * FROM equipamento WHERE submetido_certificacao = 'Submetido'","Equipamentos com Pedido de Certificação");
            }
        });
    gbc.gridx = 2;
    janelaNotificacoes.add(botaoCertificacoes, gbc);

    // Botão 4 - Técnicos que recusaram
    JButton botaoRecusas = new JButton("Técnicos Recusas");
    botaoRecusas.setPreferredSize(new Dimension(150, 40));
    botaoRecusas.setFont(new Font("Arial", Font.PLAIN, 12));
    botaoRecusas.setBackground(new Color(255, 193, 7));
    botaoRecusas.setForeground(Color.BLACK);
    botaoRecusas.addActionListener(new ActionListener() 
    {
        public void actionPerformed(ActionEvent e) 
        {
            buscarTecnicos(labelInfo, scrollPane,"SELECT * FROM tecnico WHERE escolhido_certificacao = 'Negado pelo Tecnico'","Técnicos que Recusaram Certificação");
        }
    });
    gbc.gridx = 3;
    janelaNotificacoes.add(botaoRecusas, gbc);

    // Botão Cancelar
    JButton botaoCancelar = new JButton("Sair");
    botaoCancelar.setPreferredSize(new Dimension(200, 40));
    botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
    botaoCancelar.setBackground(new Color(128, 128, 128));
    botaoCancelar.setForeground(Color.WHITE);
    botaoCancelar.addActionListener(new ActionListener() 
    {
        public void actionPerformed(ActionEvent e) 
        {
            janelaNotificacoes.dispose();
        }
    });
    gbc.gridx = 1;
    gbc.gridy = 3;
    gbc.gridwidth = 2;
    gbc.insets = new Insets(15, 15, 10, 15);
    janelaNotificacoes.add(botaoCancelar, gbc);
    
    janelaNotificacoes.setVisible(true);
}

    /**
     * Método para buscar e exibir utilizadores
     * 
     * @author Guilherme Rodrigues
     * 
     * @param labelInfo JLabel para exibir as informações dos utilizadores
     * @param scrollPane JScrollPane para permitir rolagem das informações
     * @param sql String contendo a consulta SQL para buscar os utilizadores
     * @param titulo Título a ser exibido na parte superior das informações
     */
    private static void buscarUtilizadores(JLabel labelInfo, JScrollPane scrollPane, String sql, String titulo) 
    {
        try 
        {
            Conexao_BD conexaoBD = new Conexao_BD();
            Connection conn = conexaoBD.conexao();
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            StringBuilder resultados = new StringBuilder();
            resultados.append("<html><div style='text-align: center; padding: 10px;'>");
            resultados.append("<h2 style='color: #2c3e50;'>").append(titulo).append("</h2>");
            
            boolean encontrouResultados = false;
            
            while (rs.next()) 
            {
                encontrouResultados = true;
                int id_utilizador = rs.getInt("id_utilizador");
                String username = rs.getString("username_utilizador");
                String nome = rs.getString("nome_utilizador");
                String email = rs.getString("email_utilizador");
                String tipo = rs.getString("tipo");
                boolean estado = rs.getBoolean("estado_utilizador");
                
                resultados.append("─────────────────────────<br>");
                resultados.append("<b>ID:</b> ").append(id_utilizador).append("<br>");
                resultados.append("<b>Nome:</b> ").append(nome).append("<br>");
                resultados.append("<b>Username:</b> ").append(username).append("<br>");
                resultados.append("<b>Email:</b> ").append(email).append("<br>");
                resultados.append("<b>Tipo:</b> ").append(tipo).append("<br>");
                
                if (estado) 
                {
                    resultados.append("<span style='color: green;'><b>Estado:</b> ATIVO</span><br><br>");
                } 
                else 
                {
                    resultados.append("<span style='color: red;'><b>Estado:</b> INATIVO</span><br><br>");
                }
            }
            
            if (!encontrouResultados) 
            {
                resultados.append("<p style='color: #e74c3c; font-size: 16px;'>");
                resultados.append("Nenhum resultado encontrado para esta categoria.");
                resultados.append("</p>");
            }
            
            resultados.append("</div></html>");
            labelInfo.setText(resultados.toString());
            
            // Fazer scroll para o topo após carregar os dados
            SwingUtilities.invokeLater(() -> {
                scrollPane.getVerticalScrollBar().setValue(0);
            });
            
            rs.close();
            pstmt.close();
            conn.close();
            
        } 
        catch (SQLException ex) 
        {
            labelInfo.setText("<html><div style='color: red; text-align: center; padding: 20px;'>" + "<h3>Erro ao buscar dados:</h3>" + "<p>" + ex.getMessage() + "</p></div></html>");
            System.out.println("Erro SQL: " + ex.getMessage());
        }
    }

    /**
     * Método para buscar e exibir equipamentos
     * 
     * @author Guilherme Rodrigues
     * 
     * @param labelInfo JLabel para exibir as informações dos equipamentos
     * @param scrollPane JScrollPane para permitir rolagem das informações
     * @param sql String contendo a consulta SQL para buscar os equipamentos
     * @param titulo Título a ser exibido na parte superior das informações
     */
    private static void buscarEquipamentos(JLabel labelInfo, JScrollPane scrollPane, String sql, String titulo) {
        try 
        {
            Conexao_BD conexaoBD = new Conexao_BD();
            Connection conn = conexaoBD.conexao();
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            StringBuilder resultados = new StringBuilder();
            resultados.append("<html><div style='text-align: center; padding: 10px;'>");
            resultados.append("<h2 style='color: #2c3e50;'>").append(titulo).append("</h2>");
            
            boolean encontrouResultados = false;
            
            while (rs.next()) 
            {
                encontrouResultados = true;
                int id_equipamento = rs.getInt("id_equipamento");
                int id_utilizador = rs.getInt("id_utilizador");
                String marca_equipamento = rs.getString("marca_equipamento");
                String modelo_equipamento = rs.getString("modelo_equipamento");
                
                resultados.append("─────────────────────────<br>");
                resultados.append("<b>ID:</b> ").append(id_equipamento).append("<br>");
                resultados.append("<b>Marca:</b> ").append(marca_equipamento).append("<br>");
                resultados.append("<b>Modelo:</b> ").append(modelo_equipamento).append("<br>");
                resultados.append("<b>ID Fabricante:</b> ").append(id_utilizador).append("<br><br>");
            }
            
            if (!encontrouResultados) 
            {
                resultados.append("<p style='color: #e74c3c; font-size: 16px;'>");
                resultados.append("Nenhum resultado encontrado para esta categoria.");
                resultados.append("</p>");
            }
            
            resultados.append("</div></html>");
            labelInfo.setText(resultados.toString());
            
            // Fazer scroll para o topo após carregar os dados
            SwingUtilities.invokeLater(() -> {
                scrollPane.getVerticalScrollBar().setValue(0);
            });
            
            rs.close();
            pstmt.close();
            conn.close();
            
        } 
        catch (SQLException ex) 
        {
            labelInfo.setText("<html><div style='color: red; text-align: center; padding: 20px;'>" + "<h3>Erro ao buscar dados:</h3>" + "<p>" + ex.getMessage() + "</p></div></html>");
            System.out.println("Erro SQL: " + ex.getMessage());
        }
    }

    /**
     * Método para buscar e exibir técnicos
     * 
     * @author Guilherme Rodrigues
     * 
     * @param labelInfo JLabel para exibir as informações dos técnicos
     * @param scrollPane JScrollPane para permitir rolagem das informações
     * @param sql String contendo a consulta SQL para buscar os técnicos
     * @param titulo Título a ser exibido na parte superior das informações
     */
    private static void buscarTecnicos(JLabel labelInfo, JScrollPane scrollPane, String sql, String titulo) {
        try 
        {
            Conexao_BD conexaoBD = new Conexao_BD();
            Connection conn = conexaoBD.conexao();
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            StringBuilder resultados = new StringBuilder();
            resultados.append("<html><div style='text-align: center; padding: 10px;'>");
            resultados.append("<h2 style='color: #2c3e50;'>").append(titulo).append("</h2>");
            
            boolean encontrouResultados = false;
            
            while (rs.next()) 
            {
                encontrouResultados = true;
                int id_utilizador = rs.getInt("id_utilizador");
                String username = rs.getString("username_utilizador");
                
                resultados.append("─────────────────────────<br>");
                resultados.append("<b>ID:</b> ").append(id_utilizador).append("<br>");
                resultados.append("<b>Username:</b> ").append(username).append("<br><br>");
            }
            
            if (!encontrouResultados) 
            {
                resultados.append("<p style='color: #e74c3c; font-size: 16px;'>");
                resultados.append("Nenhum resultado encontrado para esta categoria.");
                resultados.append("</p>");
            }
            
            resultados.append("</div></html>");
            labelInfo.setText(resultados.toString());
            
            // Fazer scroll para o topo após carregar os dados
            SwingUtilities.invokeLater(() -> {
                scrollPane.getVerticalScrollBar().setValue(0);
            });
            
            rs.close();
            pstmt.close();
            conn.close();
            
        } 
        catch (SQLException ex) 
        {
            labelInfo.setText("<html><div style='color: red; text-align: center; padding: 20px;'>" + "<h3>Erro ao buscar dados:</h3>" + "<p>" + ex.getMessage() + "</p></div></html>");
            System.out.println("Erro SQL: " + ex.getMessage());
        }
    }

    /** 
     * Método para abrir a janela de visualização de informação do utilizador
     * Este método cria uma nova janela JFrame para visualizar informações de um utilizador específico.
     * 
     * @author Guilherme Rodrigues
     * 
     * @param id ID do utilizador a ser visualizado
     */
    private void abrirJanelaVisualizarInformacao(int id) 
    {
        JFrame janelaVisualizar = new JFrame("Visualizar Informação do Utilizador");
        janelaVisualizar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaVisualizar.setSize(700, 600);
        janelaVisualizar.setLocationRelativeTo(this);
        janelaVisualizar.setLayout(new GridBagLayout());
        janelaVisualizar.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Visualizar Informação do Utilizador", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaVisualizar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        JLabel labelId = new JLabel("ID do Utilizador:");
        labelId.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaVisualizar.add(labelId, gbc);

        JTextField campoId = new JTextField(20);
        campoId.setEnabled(false);
        campoId.setPreferredSize(new Dimension(250, 35));
        campoId.setFont(new Font("Arial", Font.PLAIN, 14));
        if (id != 0) 
        {
            campoId.setText(String.valueOf(id));
        }
        gbc.gridx = 1;
        janelaVisualizar.add(campoId, gbc);

        DefaultTableModel tableModel = new DefaultTableModel();
        JTable tabela = new JTable(tableModel);
        tableModel.addColumn("Campo");
        tableModel.addColumn("Valor");

        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setPreferredSize(new Dimension(650, 300));
        scrollPane.setBorder(BorderFactory.createTitledBorder("Informações do Utilizador"));

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaVisualizar.add(scrollPane, gbc);

        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        JButton botaoPesquisar = new JButton("Pesquisar Utilizador");
        botaoPesquisar.setPreferredSize(new Dimension(200, 40));
        botaoPesquisar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoPesquisar.setBackground(new Color(70, 130, 180));
        botaoPesquisar.setForeground(Color.WHITE);
        botaoPesquisar.addActionListener(e -> {
            String idText = campoId.getText().trim();
            if (idText.isEmpty()) 
            {
                JOptionPane.showMessageDialog(janelaVisualizar, "Por favor, insira um ID para pesquisar.");
                return;
            }
            try 
            {
                int id_utilizador = Integer.parseInt(idText);
                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();
                String sql = "SELECT * FROM utilizador WHERE id_utilizador = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, id_utilizador);
                ResultSet rs = stmt.executeQuery();
                tableModel.setRowCount(0);
                if (rs.next()) 
                {
                    tableModel.addRow(new Object[]{"ID", rs.getInt("id_utilizador")});
                    tableModel.addRow(new Object[]{"Nome", rs.getString("nome_utilizador")});
                    tableModel.addRow(new Object[]{"Username", rs.getString("username_utilizador")});
                    tableModel.addRow(new Object[]{"Email", rs.getString("email_utilizador")});
                    tableModel.addRow(new Object[]{"Tipo", rs.getString("tipo")});
                    tableModel.addRow(new Object[]{"Estado", rs.getBoolean("estado_utilizador") ? "Ativo" : "Inativo"});
                    tableModel.addRow(new Object[]{"Pedido Remoção", rs.getBoolean("pedido_remocao") ? "Sim" : "Não"});
                    String tipo = rs.getString("tipo");
                    if ("Tecnico".equalsIgnoreCase(tipo)) {
                        visualizarTecnicoGUI(id_utilizador, conn, tableModel);
                    } else if ("Fabricante".equalsIgnoreCase(tipo)) {
                        visualizarFabricanteGUI(id_utilizador, conn, tableModel);
                    }
                } 
                else 
                {
                    JOptionPane.showMessageDialog(janelaVisualizar, "Nenhum utilizador encontrado com o ID " + idText);
                }
                rs.close();
                stmt.close();
                conn.close();
            } 
            catch (Exception ex) 
            {
                JOptionPane.showMessageDialog(janelaVisualizar, "Erro ao consultar utilizador: " + ex.getMessage());
            }
        });
        gbc.gridy = 3;
        gbc.insets = new Insets(15, 15, 10, 15);
        gbc.gridx = 0;
        janelaVisualizar.add(botaoPesquisar, gbc);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaVisualizar.dispose());
        gbc.gridx = 1;
        janelaVisualizar.add(botaoCancelar, gbc);

        if (id != 0) 
        {
            SwingUtilities.invokeLater(botaoPesquisar::doClick);
        }

        janelaVisualizar.setVisible(true);
    }

    /** Método para visualizar informações do técnico
     * Este método preenche o modelo da tabela com as informações do técnico.
     * @param id ID do técnico a ser visualizado
     * @param conn Conexão com o banco de dados
     * @param model Modelo da tabela onde as informações serão adicionadas
     * @throws SQLException Se ocorrer um erro ao acessar o banco de dados
     */
    private void visualizarTecnicoGUI(int id, Connection conn, DefaultTableModel model) throws SQLException 
    {
        String sql = "SELECT * FROM tecnico WHERE id_utilizador = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) 
        {
            model.addRow(new Object[]{"NIF", rs.getString("nif_tecnico")});
            model.addRow(new Object[]{"Telefone", rs.getString("telefone_tecnico")});
            model.addRow(new Object[]{"Morada", rs.getString("morada_tecnico")});
            model.addRow(new Object[]{"Nível de Certificação", rs.getString("nivel_certificacao")});
            model.addRow(new Object[]{"Área de Especialização", rs.getString("area_especializacao")});
        }
        rs.close();
        stmt.close();
    }

    /** Método para visualizar informações do fabricante
     * Este método preenche o modelo da tabela com as informações do fabricante.
     * @param id ID do fabricante a ser visualizado
     * @param conn Conexão com o banco de dados
     * @param model Modelo da tabela onde as informações serão adicionadas
     * @throws SQLException Se ocorrer um erro ao acessar o banco de dados
     */ 
    private void visualizarFabricanteGUI(int id, Connection conn, DefaultTableModel model) throws SQLException 
    {
        String sql = "SELECT * FROM fabricante WHERE id_utilizador = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) 
        {
            model.addRow(new Object[]{"NIF", rs.getString("nif_fabricante")});
            model.addRow(new Object[]{"Telefone", rs.getString("telefone_fabricante")});
            model.addRow(new Object[]{"Morada", rs.getString("morada_fabricante")});
            model.addRow(new Object[]{"Setor Comercial", rs.getString("sector_comercial")});
            model.addRow(new Object[]{"Início de Atividade", rs.getString("inicio_actividade")});
        }
        rs.close();
        stmt.close();
    }
    
    /**    
     * Método para abrir a janela de atualização de utilizador
     * Este método cria uma nova janela JFrame para atualizar informações de um utilizador específico.
     * @author Guilherme Rodrigues
     * 
     * @param id ID do utilizador a ser atualizado
     */
    private void abrirJanelaAtualizarUtilizador(int id) 
    {
        JFrame janelaAtualizar = new JFrame("Atualizar Utilizador");
        janelaAtualizar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaAtualizar.setSize(700, 600);
        janelaAtualizar.setLocationRelativeTo(this);
        janelaAtualizar.setLayout(new GridBagLayout());
        janelaAtualizar.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Atualizar Utilizador ID: " + id, JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaAtualizar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        DefaultTableModel tableModel = new DefaultTableModel();
        JTable tabela = new JTable(tableModel);
        tableModel.addColumn("Campo");
        tableModel.addColumn("Valor");

        JScrollPane scrollDados = new JScrollPane(tabela);
        scrollDados.setPreferredSize(new Dimension(600, 200));
        scrollDados.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollDados.setBorder(BorderFactory.createTitledBorder("Dados Atuais"));

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 0.4;
        janelaAtualizar.add(scrollDados, gbc);

        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        JLabel labelCampo = new JLabel("Campo a Atualizar:");
        labelCampo.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 2;
        janelaAtualizar.add(labelCampo, gbc);

        JComboBox<String> comboCampos = new JComboBox<>();
        comboCampos.setPreferredSize(new Dimension(250, 35));
        comboCampos.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaAtualizar.add(comboCampos, gbc);

        JLabel labelNovoValor = new JLabel("Novo Valor:");
        labelNovoValor.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 3;
        janelaAtualizar.add(labelNovoValor, gbc);

        JTextField campoNovoValor = new JTextField();
        campoNovoValor.setPreferredSize(new Dimension(250, 35));
        campoNovoValor.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaAtualizar.add(campoNovoValor, gbc);

        JCheckBox checkBoxValor = new JCheckBox();
        checkBoxValor.setFont(new Font("Arial", Font.PLAIN, 14));
        checkBoxValor.setBackground(Color.LIGHT_GRAY);
        checkBoxValor.setVisible(false);
        gbc.gridx = 1;
        gbc.gridy = 3;
        janelaAtualizar.add(checkBoxValor, gbc);

        try 
        {
            Conexao_BD conexaoBD = new Conexao_BD();
            Connection conn = conexaoBD.conexao();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM utilizador WHERE id_utilizador = ?");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (!rs.next()) 
            {
                JOptionPane.showMessageDialog(janelaAtualizar, "Utilizador com ID " + id + " não encontrado.");
                janelaAtualizar.dispose();
                return;
            }

            tableModel.addRow(new Object[]{"ID", rs.getInt("id_utilizador")});
            tableModel.addRow(new Object[]{"Nome", rs.getString("nome_utilizador")});
            tableModel.addRow(new Object[]{"Username", rs.getString("username_utilizador")});
            tableModel.addRow(new Object[]{"Email", rs.getString("email_utilizador")});
            tableModel.addRow(new Object[]{"Tipo", rs.getString("tipo")});
            tableModel.addRow(new Object[]{"Estado", rs.getBoolean("desativado") ? "Desativado" : "Ativo"});

            String tipo = rs.getString("tipo");

            comboCampos.addItem("Nome");
            comboCampos.addItem("Username");
            comboCampos.addItem("Email");
            comboCampos.addItem("Password");
            comboCampos.addItem("Estado");
            comboCampos.addItem("Desativado");

            if ("Tecnico".equalsIgnoreCase(tipo)) 
            {
                comboCampos.addItem("NIF");
                comboCampos.addItem("Telefone");
                comboCampos.addItem("Morada");
                comboCampos.addItem("Nivel de Certificacao");
                comboCampos.addItem("Area de Especializacao");
            } 
            else if ("Fabricante".equalsIgnoreCase(tipo)) 
            {
                comboCampos.addItem("NIF");
                comboCampos.addItem("Telefone");
                comboCampos.addItem("Morada");
                comboCampos.addItem("Setor Comercial");
                comboCampos.addItem("Inicio de atividade");
            }

            rs.close();
            stmt.close();
            conn.close();

        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(janelaAtualizar, "Erro ao carregar dados do utilizador: " + ex.getMessage());
            janelaAtualizar.dispose();
            return;
        }

        comboCampos.addActionListener(e -> {
            String campo = (String) comboCampos.getSelectedItem();
            campoNovoValor.setVisible(!(campo.equals("Estado") || campo.equals("Desativado")));
            checkBoxValor.setVisible(campo.equals("Estado") || campo.equals("Desativado"));
        });

        JButton botaoAtualizar = new JButton("Atualizar");
        botaoAtualizar.setPreferredSize(new Dimension(200, 40));
        botaoAtualizar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoAtualizar.setBackground(new Color(34, 139, 34));
        botaoAtualizar.setForeground(Color.WHITE);
        botaoAtualizar.addActionListener(e -> {
            String campoSelecionado = (String) comboCampos.getSelectedItem();
            if (campoSelecionado == null) 
            {
                JOptionPane.showMessageDialog(janelaAtualizar, "Selecione um campo para atualizar.");
                return;
            }
            try 
            {
                String novoValor = "";
                boolean valorBoolean = false;
                if (campoSelecionado.equals("Estado") || campoSelecionado.equals("Desativado")) 
                {
                    valorBoolean = checkBoxValor.isSelected();
                } 
                else 
                {
                    novoValor = campoNovoValor.getText().trim();
                    if (novoValor.isEmpty()) 
                    {
                        JOptionPane.showMessageDialog(janelaAtualizar, "Digite o novo valor.");
                        return;
                    }
                }
                Conexao_BD conexaoBD = new Conexao_BD();
                Connection conn = conexaoBD.conexao();
                String tipoSql = "SELECT tipo FROM utilizador WHERE id_utilizador = ?";
                PreparedStatement tipoStmt = conn.prepareStatement(tipoSql);
                tipoStmt.setInt(1, id);
                ResultSet tipoRs = tipoStmt.executeQuery();
                if (tipoRs.next()) 
                {
                    String tipo = tipoRs.getString("tipo");
                    String campo = obterNomeCampo(campoSelecionado, tipo);
                    if (campoSelecionado.equals("Estado") || campoSelecionado.equals("Desativado")) 
                    {
                        atualizarUtilizador(id, campo, String.valueOf(valorBoolean));
                        if (campoSelecionado.equals("Desativado") && valorBoolean) 
                        {
                            atualizarUtilizador(id, "estado_utilizador", "false");
                        } 
                        else if (campoSelecionado.equals("Desativado") && !valorBoolean) {

                            atualizarUtilizador(id, "estado_utilizador", "true");
                        }
                    } else {
                        if (campoSelecionado.equals("Nome") || campoSelecionado.equals("Username") || campoSelecionado.equals("Email") || campoSelecionado.equals("Password")) 
                        {
                            atualizarUtilizador(id, campo, novoValor);
                        } 
                        else 
                        {
                            atualizarEspecializado(id, campo, novoValor, tipo);
                        }
                    }
                    JOptionPane.showMessageDialog(janelaAtualizar, "Utilizador atualizado com sucesso!");
                    janelaAtualizar.dispose();
                }
                tipoRs.close();
                tipoStmt.close();
                conn.close();
            } 
            catch (SQLException ex) 
            {
                JOptionPane.showMessageDialog(janelaAtualizar, "Erro ao atualizar utilizador: " + ex.getMessage());
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(20, 15, 10, 15);
        janelaAtualizar.add(botaoAtualizar, gbc);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(ev -> janelaAtualizar.dispose());
        gbc.gridx = 1;
        janelaAtualizar.add(botaoCancelar, gbc);

        janelaAtualizar.setVisible(true);
    }

    /**
     * Método auxiliar para obter o nome do campo correto baseado no tipo de utilizador
     * 
     * @author Guilherme Rodrigues
     * 
     * @param campoSelecionado Campo selecionado na interface
     * @param tipo Tipo de utilizador (Técnico ou Fabricante)
     * @return Nome do campo correspondente na tabela
     * 
     */
    private void abrirJanelaInserirCertificacao(int id_utilizador) 
    {
        JFrame janelaCertificacao = new JFrame("Inserir Certificação");
        janelaCertificacao.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaCertificacao.setSize(700, 650);
        janelaCertificacao.setLocationRelativeTo(this);
        janelaCertificacao.setLayout(new GridBagLayout());
        janelaCertificacao.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Inserir Nova Certificação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaCertificacao.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo ID do Equipamento
        JLabel labelIdEquipamento = new JLabel("ID do Equipamento:");
        labelIdEquipamento.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaCertificacao.add(labelIdEquipamento, gbc);

        JTextField campoIdEquipamento = new JTextField();
        campoIdEquipamento.setPreferredSize(new Dimension(200, 30));
        campoIdEquipamento.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaCertificacao.add(campoIdEquipamento, gbc);

        // Label para mostrar dados do equipamento
        JLabel labelDadosEquipamento = new JLabel(" ");
        labelDadosEquipamento.setFont(new Font("Arial", Font.PLAIN, 12));
        labelDadosEquipamento.setForeground(Color.BLUE);
        labelDadosEquipamento.setVerticalAlignment(JLabel.TOP);
        
        JScrollPane scrollDados = new JScrollPane(labelDadosEquipamento);
        scrollDados.setPreferredSize(new Dimension(600, 120));
        scrollDados.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollDados.setBorder(BorderFactory.createTitledBorder("Dados do Equipamento"));
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 0.2;
        janelaCertificacao.add(scrollDados, gbc);

        // Reset das configurações
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // Campo Observações Gerais
        JLabel labelObservacoes = new JLabel("Observações Gerais:");
        labelObservacoes.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 3;
        janelaCertificacao.add(labelObservacoes, gbc);

        JTextArea campoObservacoes = new JTextArea(4, 20);
        campoObservacoes.setFont(new Font("Arial", Font.PLAIN, 12));
        campoObservacoes.setLineWrap(true);
        campoObservacoes.setWrapStyleWord(true);
        JScrollPane scrollObservacoes = new JScrollPane(campoObservacoes);
        scrollObservacoes.setPreferredSize(new Dimension(300, 80));
        scrollObservacoes.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        gbc.gridx = 1;
        janelaCertificacao.add(scrollObservacoes, gbc);

        // Campo Custo da Certificação
        JLabel labelCusto = new JLabel("Custo da Certificação (€):");
        labelCusto.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 4;
        janelaCertificacao.add(labelCusto, gbc);

        JTextField campoCusto = new JTextField();
        campoCusto.setPreferredSize(new Dimension(200, 30));
        campoCusto.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaCertificacao.add(campoCusto, gbc);

        // Botão Verificar Equipamento
        JButton botaoVerificar = new JButton("Verificar Equipamento");
        botaoVerificar.setPreferredSize(new Dimension(180, 40));
        botaoVerificar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoVerificar.setBackground(new Color(70, 130, 180));
        botaoVerificar.setForeground(Color.WHITE);
        
        botaoVerificar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String idText = campoIdEquipamento.getText().trim();
                if (idText.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "Por favor, insira o ID do equipamento.");
                    return;
                }

                try 
                {
                    int id_equipamento = Integer.parseInt(idText);
                    
                    // Verificação inicial igual ao código original
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    String sql = "SELECT * FROM equipamento WHERE id_equipamento = ? AND submetido_certificacao = 'Submetido' AND id_certificacao IS NULL";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, id_equipamento);
                    ResultSet rs = stmt.executeQuery();
                    
                    if (!rs.next()) 
                    {
                        JOptionPane.showMessageDialog(janelaCertificacao, "Nenhum pedido de certificacao para este equipamento.");
                        labelDadosEquipamento.setText(" ");
                        stmt.close();
                        conn.close();
                        return;
                    }
                    
                    // Mostrar dados do equipamento
                    StringBuilder dadosEquipamento = new StringBuilder();
                    dadosEquipamento.append("<html><div style='text-align: center; padding: 10px;'>");
                    dadosEquipamento.append("─────────────────────────<br>");
                    dadosEquipamento.append("<b>ID Equipamento:</b> ").append(rs.getInt("id_equipamento")).append("<br>");
                    
                    // Verificar se existem outras colunas comuns em equipamento
                    try {
                        if (rs.getString("nome_equipamento") != null) {
                            dadosEquipamento.append("<b>Nome:</b> ").append(rs.getString("nome_equipamento")).append("<br>");
                        }
                    } catch (SQLException ignored) {}
                    
                    try {
                        if (rs.getString("modelo") != null) {
                            dadosEquipamento.append("<b>Modelo:</b> ").append(rs.getString("modelo")).append("<br>");
                        }
                    } catch (SQLException ignored) {}
                    
                    try {
                        if (rs.getString("submetido_certificacao") != null) {
                            String statusSubmissao = rs.getString("submetido_certificacao");
                            if ("Submetido".equalsIgnoreCase(statusSubmissao)) {
                                dadosEquipamento.append("<span style='color: orange;'><b>Status Certificação:</b> ").append(statusSubmissao).append("</span><br>");
                            } else {
                                dadosEquipamento.append("<b>Status Certificação:</b> ").append(statusSubmissao).append("<br>");
                            }
                        }
                    } catch (SQLException ignored) {}
                    
                    dadosEquipamento.append("<span style='color: green;'><b>Status:</b> EQUIPAMENTO ENCONTRADO</span><br>");
                    dadosEquipamento.append("─────────────────────────<br>");
                    dadosEquipamento.append("</div></html>");
                    
                    labelDadosEquipamento.setText(dadosEquipamento.toString());
                    
                    rs.close();
                    stmt.close();
                    conn.close();
                    
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "ID deve ser um número válido.");
                }
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "Erro ao verificar equipamento: " + ex.getMessage());
                }
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.insets = new Insets(20, 15, 10, 15);
        janelaCertificacao.add(botaoVerificar, gbc);

        // Botão Aceitar Certificação
        JButton botaoAceitar = new JButton("Aceitar Certificação");
        botaoAceitar.setPreferredSize(new Dimension(180, 40));
        botaoAceitar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoAceitar.setBackground(new Color(34, 139, 34));
        botaoAceitar.setForeground(Color.WHITE);
        
        botaoAceitar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String idText = campoIdEquipamento.getText().trim();
                String observacoes = campoObservacoes.getText().trim();
                String custoText = campoCusto.getText().trim();
                
                if (idText.isEmpty() || observacoes.isEmpty() || custoText.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "Preencha todos os campos obrigatórios.");
                    return;
                }
                
                try 
                {
                    int id_equipamento = Integer.parseInt(idText);
                    float custo = Float.parseFloat(custoText);
                    
                    if (custo < 0) 
                    {
                        JOptionPane.showMessageDialog(janelaCertificacao, "O custo deve ser um valor positivo.");
                        return;
                    }
                    
                    // Confirmar ação
                    int confirmacao = JOptionPane.showConfirmDialog(
                        janelaCertificacao,
                        "Deseja realmente aceitar esta certificação?\n\nEquipamento ID: " + id_equipamento + 
                        "\nCusto: €" + String.format("%.2f", custo),
                        "Confirmar Certificação",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                    );
                    
                    if (confirmacao == JOptionPane.YES_OPTION) 
                    {
                        Conexao_BD conexaoBD = new Conexao_BD();
                        Connection conn = conexaoBD.conexao();
                        
                        // Verificar se equipamento existe e se tem pedido de certificação
                        String sqlCheck = "SELECT * FROM equipamento WHERE id_equipamento = ?";
                        PreparedStatement stmtCheck = conn.prepareStatement(sqlCheck);
                        stmtCheck.setInt(1, id_equipamento);
                        ResultSet rsCheck = stmtCheck.executeQuery();
                        
                        if (!rsCheck.next()) 
                        {
                            JOptionPane.showMessageDialog(janelaCertificacao, "Nenhum pedido de certificacao para este equipamento.");
                            stmtCheck.close();
                            conn.close();
                            return;
                        }
                        
                        // Inserir certificação
                        LocalDate dataAtual = LocalDate.now();
                        java.sql.Date dataCertificacaoSQL = java.sql.Date.valueOf(dataAtual);
                        
                        String sql1 = "INSERT INTO certificacao (id_utilizador, data_realizacao, observacoes_genericas, custo_certificacao, estado) " +
                                            "VALUES (?, ?, ?, ?, ?)";
                        PreparedStatement stmt1 = conn.prepareStatement(sql1);
                        stmt1.setInt(1, id_utilizador);
                        stmt1.setDate(2, dataCertificacaoSQL);
                        stmt1.setString(3, observacoes);
                        stmt1.setFloat(4, custo);
                        stmt1.setString(5, "aceite");
                        
                        stmt1.executeUpdate();
                        stmt1.close();
                        
                        // Obter ID da certificação inserida
                        String sql2 = "SELECT MAX(id_certificacao) FROM certificacao";
                        PreparedStatement stmt2 = conn.prepareStatement(sql2);
                        ResultSet rs = stmt2.executeQuery();
                        
                        int id_certificacao = 0;
                        if (rs.next()) 
                        {
                            id_certificacao = rs.getInt(1);
                        }
                        
                        if (id_certificacao == 0) 
                        {
                            JOptionPane.showMessageDialog(janelaCertificacao, "Não foi possível introduzir a certificação!");
                            rs.close();
                            stmt2.close();
                            rsCheck.close();
                            stmtCheck.close();
                            conn.close();
                            return;
                        }
                        
                        // Atualizar equipamento
                        String sql3 = "UPDATE equipamento SET id_certificacao = ?, submetido_certificacao = 'Aceite' WHERE id_equipamento = ?";
                        PreparedStatement stmt3 = conn.prepareStatement(sql3);
                        stmt3.setInt(1, id_certificacao);
                        stmt3.setInt(2, id_equipamento);
                        stmt3.executeUpdate();
                        stmt3.close();
                        
                        // Atualizar técnico
                        String sql4 = "UPDATE tecnico SET escolhido_certificacao = 'Aceite pelo Tecnico' WHERE id_utilizador = ?";
                        PreparedStatement stmt4 = conn.prepareStatement(sql4);
                        stmt4.setInt(1, id_utilizador);
                        stmt4.executeUpdate();
                        stmt4.close();
                        
                        rs.close();
                        stmt2.close();
                        rsCheck.close();
                        stmtCheck.close();
                        conn.close();
                        
                        JOptionPane.showMessageDialog(janelaCertificacao, 
                            "Certificação inserida com sucesso!\n\nID da Certificação: " + id_certificacao + 
                            "\nData: " + dataAtual.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) +
                            "\nCusto: €" + String.format("%.2f", custo));
                        
                        // Limpar campos após sucesso
                        campoIdEquipamento.setText("");
                        campoObservacoes.setText("");
                        campoCusto.setText("");
                        labelDadosEquipamento.setText(" ");
                    }
                    
                } 
                catch (NumberFormatException ex) 
                {
                    if (ex.getMessage().contains("equipamento")) {
                        JOptionPane.showMessageDialog(janelaCertificacao, "ID do equipamento deve ser um número válido.");
                    } else {
                        JOptionPane.showMessageDialog(janelaCertificacao, "Custo deve ser um número válido.");
                    }
                }
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "Erro ao inserir certificação: " + ex.getMessage());
                }
            }
        });
        
        gbc.gridx = 1;
        janelaCertificacao.add(botaoAceitar, gbc);

        // Botão Recusar Certificação
        JButton botaoRecusar = new JButton("Recusar Certificação");
        botaoRecusar.setPreferredSize(new Dimension(180, 40));
        botaoRecusar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoRecusar.setBackground(new Color(220, 20, 60));
        botaoRecusar.setForeground(Color.WHITE);
        
        botaoRecusar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String idText = campoIdEquipamento.getText().trim();
                
                if (idText.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "Por favor, insira o ID do equipamento.");
                    return;
                }
                
                try 
                {
                    int id_equipamento = Integer.parseInt(idText);
                    
                    // Confirmar ação
                    int confirmacao = JOptionPane.showConfirmDialog(
                        janelaCertificacao,
                        "Deseja realmente recusar esta certificação?\n\nEquipamento ID: " + id_equipamento + 
                        "\n\nO gestor será notificado automaticamente.",
                        "Confirmar Recusa",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                    );
                    
                    if (confirmacao == JOptionPane.YES_OPTION) 
                    {
                        Conexao_BD conexaoBD = new Conexao_BD();
                        Connection conn = conexaoBD.conexao();
                        
                        // Atualizar técnico
                        String sql4 = "UPDATE tecnico SET escolhido_certificacao = 'Negado pelo Tecnico' WHERE id_utilizador = ?";
                        PreparedStatement stmt4 = conn.prepareStatement(sql4);
                        stmt4.setInt(1, id_utilizador);
                        stmt4.executeUpdate();
                        stmt4.close();
                        
                        // Atualizar equipamento
                        String sql5 = "UPDATE equipamento SET submetido_certificacao = 'Submetido' WHERE id_equipamento = ?";
                        PreparedStatement stmt5 = conn.prepareStatement(sql5);
                        stmt5.setInt(1, id_equipamento);
                        stmt5.executeUpdate();
                        stmt5.close();
                        
                        conn.close();
                        
                        JOptionPane.showMessageDialog(janelaCertificacao, "Certificação recusada com sucesso!\n\nGestor notificado automaticamente.");
                        
                        // Limpar campos após sucesso
                        campoIdEquipamento.setText("");
                        campoObservacoes.setText("");
                        campoCusto.setText("");
                        labelDadosEquipamento.setText(" ");
                    }
                    
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "ID do equipamento deve ser um número válido.");
                }
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "Erro ao recusar certificação: " + ex.getMessage());
                }
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 7;
        janelaCertificacao.add(botaoRecusar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(180, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaCertificacao.dispose();
            }
        });
        
        gbc.gridx = 1;
        janelaCertificacao.add(botaoCancelar, gbc);
        
        janelaCertificacao.setVisible(true);
    }

    /**
     * Método auxiliar para abrir a janela de pesquisa de certificações
     * 
     * @author Guilherme Rodrigues
     * 
     * @param id_utilizador ID do utilizador que está a pesquisar as certificações
     */
    private void abrirJanelaPesquisarCertificacao(int id_utilizador) 
    {
        JFrame janelaPesquisa = new JFrame("Pesquisar Certificações");
        janelaPesquisa.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaPesquisa.setSize(800, 700);
        janelaPesquisa.setLocationRelativeTo(this);
        janelaPesquisa.setLayout(new GridBagLayout());
        janelaPesquisa.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Pesquisar Certificações", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaPesquisa.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Label e ComboBox para tipo de pesquisa
        JLabel labelTipoPesquisa = new JLabel("Tipo de Pesquisa:");
        labelTipoPesquisa.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaPesquisa.add(labelTipoPesquisa, gbc);

        String[] opcoesPesquisa = {
            "1. Listar todos ordenado por data",
            "2. Listar todos ordenado por número",
            "3. Pesquisar por estado",
            "4. Pesquisar por número"
        };
        
        JComboBox<String> comboTipoPesquisa = new JComboBox<>(opcoesPesquisa);
        comboTipoPesquisa.setPreferredSize(new Dimension(300, 30));
        comboTipoPesquisa.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 1;
        janelaPesquisa.add(comboTipoPesquisa, gbc);

        // Painel para campos condicionais
        JPanel painelCamposCondicionais = new JPanel(new CardLayout());
        painelCamposCondicionais.setBackground(Color.LIGHT_GRAY);
        painelCamposCondicionais.setPreferredSize(new Dimension(300, 80));
        
        // Painel vazio para opções 1 e 2
        JPanel painelVazio = new JPanel();
        painelVazio.setBackground(Color.LIGHT_GRAY);
        painelVazio.add(new JLabel("Nenhum campo adicional necessário"));
        
        // Painel para pesquisa por estado
        JPanel painelEstado = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelEstado.setBackground(Color.LIGHT_GRAY);
        JLabel labelEstado = new JLabel("Estado:");
        labelEstado.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField campoEstado = new JTextField(15);
        campoEstado.setFont(new Font("Arial", Font.PLAIN, 12));
        painelEstado.add(labelEstado);
        painelEstado.add(campoEstado);
        
        // Painel para pesquisa por número
        JPanel painelNumero = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelNumero.setBackground(Color.LIGHT_GRAY);
        JLabel labelNumero = new JLabel("Número ID:");
        labelNumero.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField campoNumero = new JTextField(15);
        campoNumero.setFont(new Font("Arial", Font.PLAIN, 12));
        painelNumero.add(labelNumero);
        painelNumero.add(campoNumero);
        
        painelCamposCondicionais.add(painelVazio, "vazio");
        painelCamposCondicionais.add(painelEstado, "estado");
        painelCamposCondicionais.add(painelNumero, "numero");
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        janelaPesquisa.add(painelCamposCondicionais, gbc);
        gbc.gridwidth = 1;

        // Área de resultados usando JLabel com HTML (similar ao buscarUtilizadores)
        JLabel labelResultados = new JLabel();
        labelResultados.setVerticalAlignment(JLabel.TOP);
        labelResultados.setBackground(Color.WHITE);
        labelResultados.setOpaque(true);
        labelResultados.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollResultados = new JScrollPane(labelResultados);
        scrollResultados.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollResultados.setBorder(BorderFactory.createTitledBorder("Resultados da Pesquisa"));
        scrollResultados.setPreferredSize(new Dimension(700, 300));
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        janelaPesquisa.add(scrollResultados, gbc);

        // Reset das configurações
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // ActionListener para mudança no ComboBox
        comboTipoPesquisa.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                CardLayout layout = (CardLayout) painelCamposCondicionais.getLayout();
                int opcao = comboTipoPesquisa.getSelectedIndex();
                
                switch (opcao) 
                {
                    case 0: // Ordenado por data
                    case 1: // Ordenado por número
                        layout.show(painelCamposCondicionais, "vazio");
                        break;
                    case 2: // Por estado
                        layout.show(painelCamposCondicionais, "estado");
                        break;
                    case 3: // Por número
                        layout.show(painelCamposCondicionais, "numero");
                        break;
                }
            }
        });

        // Botão Pesquisar
        JButton botaoPesquisar = new JButton("Pesquisar");
        botaoPesquisar.setPreferredSize(new Dimension(180, 40));
        botaoPesquisar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoPesquisar.setBackground(new Color(70, 130, 180));
        botaoPesquisar.setForeground(Color.WHITE);
        
        botaoPesquisar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                int opcao = comboTipoPesquisa.getSelectedIndex() + 1;
                String estado = campoEstado.getText().trim();
                String numeroText = campoNumero.getText().trim();
                
                // Validações para campos obrigatórios
                if (opcao == 3 && estado.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaPesquisa, "Por favor, insira o estado para pesquisa.");
                    return;
                }
                
                if (opcao == 4 && numeroText.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaPesquisa, "Por favor, insira o número ID para pesquisa.");
                    return;
                }
                
                // Validação numérica para o ID
                int numeroId = 0;
                if (opcao == 4) 
                {
                    try 
                    {
                        numeroId = Integer.parseInt(numeroText);
                    } 
                    catch (NumberFormatException ex) 
                    {
                        JOptionPane.showMessageDialog(janelaPesquisa, "Número ID deve ser um valor numérico válido.");
                        return;
                    }
                }
                
                // Chamar método de busca
                buscarCertificacoes(labelResultados, scrollResultados, opcao, id_utilizador, estado, numeroId);
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(20, 15, 10, 15);
        janelaPesquisa.add(botaoPesquisar, gbc);

        // Botão Limpar
        JButton botaoLimpar = new JButton("Limpar Resultados");
        botaoLimpar.setPreferredSize(new Dimension(180, 40));
        botaoLimpar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoLimpar.setBackground(new Color(255, 165, 0));
        botaoLimpar.setForeground(Color.WHITE);
        botaoLimpar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                labelResultados.setText("");
                campoEstado.setText("");
                campoNumero.setText("");
                comboTipoPesquisa.setSelectedIndex(0);
            }
        });
        
        gbc.gridx = 1;
        janelaPesquisa.add(botaoLimpar, gbc);

        // Botão Fechar
        JButton botaoFechar = new JButton("Fechar");
        botaoFechar.setPreferredSize(new Dimension(180, 40));
        botaoFechar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoFechar.setBackground(new Color(128, 128, 128));
        botaoFechar.setForeground(Color.WHITE);
        botaoFechar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaPesquisa.dispose();
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        janelaPesquisa.add(botaoFechar, gbc);
        
        janelaPesquisa.setVisible(true);
    }

    /**
     * Método auxiliar para buscar certificações com base na opção selecionada
     * @author Guilherme Rodrigues
     * @param labelResultados JLabel para exibir os resultados
     * @param scrollPane JScrollPane para permitir rolagem dos resultados
     * @param opcao Opção selecionada no ComboBox (1 a 4)
     * @param id_utilizador ID do utilizador que está a pesquisar as certificações
     * @param estado Estado da certificação (se aplicável)
     * @param numeroId Número ID da certificação (se aplicável)
     */
    private static void buscarCertificacoes(JLabel labelResultados, JScrollPane scrollPane, int opcao, int id_utilizador, String estado, int numeroId) 
    {
        try 
        {
            Conexao_BD conexaoBD = new Conexao_BD();
            Connection conn = conexaoBD.conexao();
            
            PreparedStatement stmt = null;
            ResultSet rs = null;
            String sql = "";
            String titulo = "";
            
            switch (opcao) 
            {
                case 1: // Ordenado por data
                    sql = "SELECT e.id_equipamento, c.id_certificacao, c.data_realizacao FROM certificacao c LEFT JOIN equipamento e ON e.id_certificacao = c.id_certificacao WHERE c.id_utilizador = ? ORDER BY c.data_realizacao";
                    titulo = "Certificações Ordenadas por Data";
                    stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, id_utilizador);
                    break;
                    
                case 2: // Ordenado por número
                    sql = "SELECT e.id_equipamento, c.id_certificacao, c.data_realizacao FROM certificacao c LEFT JOIN equipamento e ON e.id_certificacao = c.id_certificacao WHERE c.id_utilizador = ? ORDER BY c.id_certificacao";
                    titulo = "Certificações Ordenadas por Número";
                    stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, id_utilizador);
                    break;
                    
                case 3: // Por estado
                    sql = "SELECT e.id_equipamento, c.id_certificacao, c.estado, c.data_realizacao FROM certificacao c LEFT JOIN equipamento e ON e.id_certificacao = c.id_certificacao WHERE c.id_utilizador = ? AND c.estado = ?";
                    titulo = "Certificações por Estado: " + estado;
                    stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, id_utilizador);
                    stmt.setString(2, estado);
                    break;
                    
                case 4: // Por número
                    sql = "SELECT e.id_equipamento, c.id_certificacao, c.estado, c.data_realizacao FROM certificacao c LEFT JOIN equipamento e ON e.id_certificacao = c.id_certificacao WHERE c.id_utilizador = ? AND c.id_certificacao = ?";
                    titulo = "Certificação por ID: " + numeroId;
                    stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, id_utilizador);
                    stmt.setInt(2, numeroId);
                    break;
            }
            
            rs = stmt.executeQuery();
            
            StringBuilder resultados = new StringBuilder();
            resultados.append("<html><div style='text-align: center; padding: 10px;'>");
            resultados.append("<h2 style='color: #2c3e50;'>").append(titulo).append("</h2>");
            
            boolean encontrouResultados = false;
            int contador = 0;
            
            while (rs.next()) 
            {
                encontrouResultados = true;
                contador++;
                int id_certificacao = rs.getInt("id_certificacao");
                int id_equipamento = rs.getInt("id_equipamento");
                
                resultados.append("─────────────────────────<br>");
                resultados.append("<b style='color: #2c3e50;'>Certificação #").append(contador).append("</b><br>");
                resultados.append("<b style='color: #2c3e50;'>ID Certificação:</b> ").append(id_certificacao).append("<br>");
                resultados.append("<b style='color: #2c3e50;'>ID Equipamento:</b> ").append(id_equipamento).append("<br>");
                
                // Adicionar data se disponível
                try 
                {
                    java.sql.Date data = rs.getDate("data_realizacao");
                    if (data != null) 
                    {
                        resultados.append("<b style='color: #2c3e50;'>Data Realização:</b> ").append(data.toString()).append("<br>");
                    }
                } 
                catch (SQLException ignored) {}
                
                // Adicionar estado se disponível
                try 
                {
                    String estadoResult = rs.getString("estado");
                    if (estadoResult != null) 
                    {
                        if (estadoResult.equalsIgnoreCase("ATIVO") || estadoResult.equalsIgnoreCase("APROVADO") || estadoResult.equalsIgnoreCase("VÁLIDO")) 
                        {
                            resultados.append("<span style='color: green;'><b>Estado:</b> ").append(estadoResult).append("</span><br>");
                        } 
                        else if (estadoResult.equalsIgnoreCase("INATIVO") || estadoResult.equalsIgnoreCase("REPROVADO") || estadoResult.equalsIgnoreCase("INVÁLIDO")) 
                        {
                            resultados.append("<span style='color: red;'><b>Estado:</b> ").append(estadoResult).append("</span><br>");
                        } 
                        else if (estadoResult.equalsIgnoreCase("PENDENTE") || estadoResult.equalsIgnoreCase("EM ANÁLISE")) 
                        {
                            resultados.append("<span style='color: orange;'><b>Estado:</b> ").append(estadoResult).append("</span><br>");
                        }
                        else 
                        {
                            resultados.append("<b style='color: #2c3e50;'>Estado:</b> ").append(estadoResult).append("<br>");
                        }
                    }
                } 
                catch (SQLException ignored) {}
                
                resultados.append("<br>");
            }
            
            if (!encontrouResultados) 
            {
                resultados.append("<p style='color: #e74c3c; font-size: 16px;'>");
                resultados.append("Nenhum resultado encontrado para os critérios especificados.");
                resultados.append("</p>");
            }
            else 
            {
                resultados.append("<hr style='margin-top: 20px;'>");
                resultados.append("<p style='color: #2c3e50; font-weight: bold;'>");
                resultados.append("Total de registros encontrados: ").append(contador);
                resultados.append("</p>");
            }
            
            resultados.append("</div></html>");
            labelResultados.setText(resultados.toString());
            
            // Fazer scroll para o topo após carregar os dados
            SwingUtilities.invokeLater(() -> {
                scrollPane.getVerticalScrollBar().setValue(0);
            });
            
            rs.close();
            stmt.close();
            conn.close();
            
        } 
        catch (SQLException ex) 
        {
            labelResultados.setText("<html><div style='color: red; text-align: center; padding: 20px;'>" + 
                                "<h3>Erro ao buscar certificações:</h3>" + 
                                "<p>" + ex.getMessage() + "</p></div></html>");
            System.out.println("Erro SQL: " + ex.getMessage());
        }
    }

    /**     * Método auxiliar para abrir a janela de inserção de resultados de certificação
     * 
     * @author Guilherme Rodrigues
     * 
     * @param id_utilizador ID do utilizador que está a inserir os resultados
     */
    private void abrirJanelaInserirResultadosCertificacao(int id_utilizador) 
    {
        JFrame janelaInserir = new JFrame("Inserir Resultados de Certificação");
        janelaInserir.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaInserir.setSize(650, 550);
        janelaInserir.setLocationRelativeTo(this);
        janelaInserir.setLayout(new GridBagLayout());
        janelaInserir.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ---------- COMPONENTES ----------
        JLabel titulo = new JLabel("Inserir Resultados de Certificação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaInserir.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        JTextField campoIdCert = criarCampoComLabel("ID da Certificação:", 1, janelaInserir, gbc);
        JTextField campoDescricao = criarCampoComLabel("Descrição dos Parâmetros:", 2, janelaInserir, gbc);
        JTextField campoValor = criarCampoComLabel("Valor do Parâmetro:", 3, janelaInserir, gbc);
        JTextField campoLicenca = criarCampoComLabel("Nome da Licença:", 4, janelaInserir, gbc);

        JLabel labelInfo = new JLabel(" ");
        labelInfo.setFont(new Font("Arial", Font.PLAIN, 14));
        labelInfo.setForeground(Color.BLUE);
        labelInfo.setVerticalAlignment(JLabel.TOP);

        JScrollPane scrollPane = new JScrollPane(labelInfo);
        scrollPane.setPreferredSize(new Dimension(550, 120));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Resultado"));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaInserir.add(scrollPane, gbc);
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;

        // ---------- BOTÃO INSERIR ----------
        JButton botaoInserir = new JButton("Inserir Resultados");
        botaoInserir.setPreferredSize(new Dimension(200, 40));
        botaoInserir.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoInserir.setBackground(new Color(70, 130, 180));
        botaoInserir.setForeground(Color.WHITE);

        botaoInserir.addActionListener(e -> {
            try 
            {
                // Validar campos
                String idText = campoIdCert.getText().trim();
                String descricao = campoDescricao.getText().trim();
                String valorText = campoValor.getText().trim();
                String licenca = campoLicenca.getText().trim();

                if (idText.isEmpty() || descricao.isEmpty() || valorText.isEmpty() || licenca.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaInserir, "Todos os campos são obrigatórios!");
                    return;
                }

                int id_certificacao = Integer.parseInt(idText);
                float valor = Float.parseFloat(valorText);
                java.sql.Date dataAtual = java.sql.Date.valueOf(LocalDate.now());

                Conexao_BD conexaoBD = new Conexao_BD();
                try (Connection conn = conexaoBD.conexao()) 
                {
                    // Verificar se a certificação pertence ao utilizador e ainda está válida
                    try (PreparedStatement stmt = conn.prepareStatement("SELECT id_certificacao FROM certificacao WHERE id_certificacao = ? AND id_utilizador = ? AND estado NOT IN ('finalizado', 'arquivado')"))
                    {
                        stmt.setInt(1, id_certificacao);
                        stmt.setInt(2, id_utilizador);
                        ResultSet rs = stmt.executeQuery();

                        if (!rs.next()) 
                        {
                            labelInfo.setText("<html><div style='color: red; text-align: center; padding: 10px;'>" +"<b>Erro:</b> Certificação inválida ou já encerrada.</div></html>");
                            return;
                        }
                    }

                    // Inserir parâmetros
                    try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO parametros (descricao_parametros, valor_medido, data_parametro) VALUES (?, ?, ?)")) 
                    {
                        stmt.setString(1, descricao);
                        stmt.setFloat(2, valor);
                        stmt.setDate(3, dataAtual);
                        stmt.executeUpdate();
                    }

                    // Atualizar certificação com id do último parâmetro
                    try (PreparedStatement stmt = conn.prepareStatement("UPDATE certificacao SET estado = 'decorrer', id_parametros = (SELECT COALESCE(MAX(id_parametros), 0) FROM parametros) WHERE id_certificacao = ?")) 
                    {
                        stmt.setInt(1, id_certificacao);
                        stmt.executeUpdate();
                    }

                    // Verificar e associar licença
                    boolean licencaExiste = false;
                    try (PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM licencas WHERE nome_licenca = ?")) 
                    {
                        stmt.setString(1, licenca);
                        try (ResultSet rs = stmt.executeQuery()) 
                        {
                            if (rs.next() && rs.getInt(1) > 0) {

                                licencaExiste = true;
                            }
                        }
                    }

                    if (licencaExiste) {
                        try (PreparedStatement stmt = conn.prepareStatement("UPDATE licencas SET id_certificacao = ? WHERE nome_licenca = ?")) 
                        {
                            stmt.setInt(1, id_certificacao);
                            stmt.setString(2, licenca);
                            stmt.executeUpdate();
                        }

                        labelInfo.setText("<html><div style='color: green; text-align: center; padding: 10px;'>" + "<b>Sucesso!</b> Parâmetros inseridos e licença associada.</div></html>");

                        // Limpar campos
                        campoIdCert.setText("");
                        campoDescricao.setText("");
                        campoValor.setText("");
                        campoLicenca.setText("");
                    } 
                    else 
                    {
                        labelInfo.setText("<html><div style='color: orange; text-align: center; padding: 10px;'>" +"<b>Aviso:</b> Parâmetros inseridos, mas licença não encontrada!</div></html>");
                    }
                }
        } 
        catch (NumberFormatException ex) 
        {
            JOptionPane.showMessageDialog(janelaInserir, "ID deve ser inteiro e valor do parâmetro deve ser decimal.");
        } 
        catch (SQLException ex) 
        {
            labelInfo.setText("<html><div style='color: red; text-align: center; padding: 10px;'>" + "<b>Erro SQL:</b><br>" + ex.getMessage() + "</div></html>");
            ex.printStackTrace();
        }
    });

    gbc.gridy = 6;
    gbc.gridx = 0;
    gbc.insets = new Insets(15, 15, 10, 15);
    janelaInserir.add(botaoInserir, gbc);

    //  BOTÃO CANCELAR 
    JButton botaoCancelar = new JButton("Cancelar");
    botaoCancelar.setPreferredSize(new Dimension(200, 40));
    botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
    botaoCancelar.setBackground(new Color(128, 128, 128));
    botaoCancelar.setForeground(Color.WHITE);
    botaoCancelar.addActionListener(e -> janelaInserir.dispose());

    gbc.gridx = 1;
    janelaInserir.add(botaoCancelar, gbc);

    janelaInserir.setVisible(true);
}

    /**
     * Método auxiliar para criar um campo de texto com label
     * @author Guilherme Rodrigues
     * @param texto Texto do label
     * @param y Posição vertical do campo
     * @param frame JFrame onde o campo será adicionado
     * @param gbc GridBagConstraints para posicionamento
     * @return JTextField criado
     */
    private JTextField criarCampoComLabel(String texto, int y, JFrame frame, GridBagConstraints gbc) 
    {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = y;
        frame.add(label, gbc);

        JTextField campo = new JTextField();
        campo.setPreferredSize(new Dimension(200, 30));
        campo.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        frame.add(campo, gbc);

        return campo;
    }
    
    /**
     * Método auxiliar para abrir a janela de terminar certificação
     * @author Guilherme Rodrigues
     * 
     * @param id_utilizador ID do utilizador que está a terminar a certificação
     */
    private void abrirJanelaTerminarCertificacao(int id_utilizador) 
    {
        JFrame janelaTerminar = new JFrame("Terminar Certificação");
        janelaTerminar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaTerminar.setSize(600, 450);
        janelaTerminar.setLocationRelativeTo(this);
        janelaTerminar.setLayout(new GridBagLayout());
        janelaTerminar.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Terminar Certificação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaTerminar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo ID da Certificação
        JLabel labelIdCertificacao = new JLabel("ID da Certificação:");
        labelIdCertificacao.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaTerminar.add(labelIdCertificacao, gbc);

        JTextField campoIdCertificacao = new JTextField();
        campoIdCertificacao.setPreferredSize(new Dimension(250, 35));
        campoIdCertificacao.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaTerminar.add(campoIdCertificacao, gbc);

        // Label de status
        JLabel labelStatus = new JLabel(" ");
        labelStatus.setFont(new Font("Arial", Font.PLAIN, 14));
        labelStatus.setForeground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaTerminar.add(labelStatus, gbc);
        gbc.gridwidth = 1;

        // Botão Terminar Certificação
        JButton botaoTerminar = new JButton("Terminar Certificação");
        botaoTerminar.setPreferredSize(new Dimension(200, 40));
        botaoTerminar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoTerminar.setBackground(new Color(70, 130, 180));
        botaoTerminar.setForeground(Color.WHITE);

        botaoTerminar.addActionListener(e -> {
            String idCertificacaoTexto = campoIdCertificacao.getText().trim();

            if (idCertificacaoTexto.isEmpty()) 
            {
                JOptionPane.showMessageDialog(janelaTerminar, "Por favor, insira o ID da certificação!");
                return;
            }

            try 
            {
                int idCertificacao = Integer.parseInt(idCertificacaoTexto);

                String sql = "UPDATE certificacao SET estado = 'finalizado', tempo_decorrido = AGE(NOW(), data_realizacao) WHERE id_certificacao = ? AND id_utilizador = ?";
                String sql2 = "UPDATE equipamento SET submetido_certificacao = 'terminado' WHERE id_certificacao = ?";

                Conexao_BD conexaoBD = new Conexao_BD();
                try (Connection conn = conexaoBD.conexao()) 
                {
                    try (PreparedStatement stmt = conn.prepareStatement(sql); PreparedStatement stmt2 = conn.prepareStatement(sql2)) 
                    {
                        stmt.setInt(1, idCertificacao);
                        stmt.setInt(2, id_utilizador);
                        int linhasAfetadas1 = stmt.executeUpdate();

                        stmt2.setInt(1, idCertificacao);
                        int linhasAfetadas2 = stmt2.executeUpdate();

                        if (linhasAfetadas1 > 0) 
                        {
                            labelStatus.setText("<html><div style='text-align: center;'>" + "<span style='color: green;'><b>Certificação terminada com sucesso!</b></span><br>" + "Equipamentos atualizados: " + linhasAfetadas2 + "</div></html>");
                            campoIdCertificacao.setText("");
                        } 
                        else 
                        {
                            labelStatus.setText("<html><span style='color: red;'>Certificação não encontrada ou já finalizada!</span></html>");
                        }
                    }
                }

            } 
            catch (NumberFormatException ex) 
            {
                JOptionPane.showMessageDialog(janelaTerminar, "O ID da certificação deve ser um número válido!");
            } 
            catch (SQLException ex) 
            {
                labelStatus.setText("<html><span style='color: red;'>Erro ao terminar certificação!</span></html>");
                JOptionPane.showMessageDialog(janelaTerminar, "Erro SQL: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        gbc.gridy = 3;
        gbc.gridx = 0;
        janelaTerminar.add(botaoTerminar, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaTerminar.dispose());

        gbc.gridx = 1;
        janelaTerminar.add(botaoCancelar, gbc);

        janelaTerminar.setVisible(true);
    }

    /**
     * Método auxiliar para abrir a janela de pedido de remoção de conta
     * @author Guilherme Rodrigues
     * @param id ID do utilizador que está a solicitar a remoção
     */
    private void abrirJanelaPedidoRemocao(int id) 
    {
        JFrame janelaPedido = new JFrame("Pedido de Remoção");
        janelaPedido.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaPedido.setSize(600, 400);
        janelaPedido.setLocationRelativeTo(this);
        janelaPedido.setLayout(new GridBagLayout());
        janelaPedido.getContentPane().setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Pedido de Remoção", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaPedido.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Mensagem de confirmação
        JLabel labelConfirmacao = new JLabel("Deseja realmente solicitar a remoção da sua conta?");
        labelConfirmacao.setFont(new Font("Arial", Font.PLAIN, 16));
        labelConfirmacao.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        janelaPedido.add(labelConfirmacao, gbc);
        gbc.gridwidth = 1;

        // Status
        JLabel labelStatus = new JLabel(" ");
        labelStatus.setFont(new Font("Arial", Font.PLAIN, 14));
        labelStatus.setForeground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaPedido.add(labelStatus, gbc);
        gbc.gridwidth = 1;

        // Botão Enviar Pedido
        JButton botaoEnviarPedido = new JButton("Confirmar Pedido");
        botaoEnviarPedido.setPreferredSize(new Dimension(200, 40));
        botaoEnviarPedido.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoEnviarPedido.setBackground(new Color(70, 130, 180));
        botaoEnviarPedido.setForeground(Color.WHITE);

        botaoEnviarPedido.addActionListener(e -> {
            try 
            {
                String sql = "UPDATE utilizador SET pedido_remocao = ? WHERE id_utilizador = ?";
                Conexao_BD conexaoBD = new Conexao_BD();
                try (Connection conn = conexaoBD.conexao(); PreparedStatement stmt = conn.prepareStatement(sql)) 
                {
                    stmt.setBoolean(1, true);
                    stmt.setInt(2, id);
                    int linhasAfetadas = stmt.executeUpdate();

                    if (linhasAfetadas > 0) 
                    {
                        labelStatus.setText("<html><div style='text-align: center; color: green;'><b>Pedido de remoção enviado com sucesso!</b></div></html>");
                    } 
                    else 
                    {
                        labelStatus.setText("<html><span style='color: red;'>Utilizador não encontrado ou erro ao atualizar.</span></html>");
                    }
                }
            } 
            catch (SQLException ex) 
            {
                labelStatus.setText("<html><span style='color: red;'>Erro ao processar o pedido.</span></html>");
                JOptionPane.showMessageDialog(janelaPedido, "Erro SQL: " + ex.getMessage());
                ex.printStackTrace();
            }
        });

        gbc.gridy = 3;
        gbc.gridx = 0;
        janelaPedido.add(botaoEnviarPedido, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(e -> janelaPedido.dispose());

        gbc.gridx = 1;
        janelaPedido.add(botaoCancelar, gbc);

        janelaPedido.setVisible(true);
    }

    /**
     * Método auxiliar para listar notificações de técnico
     * @author Guilherme Rodrigues
     * @param tipo Tipo de notificações (ex: "tecnico")
     * @param id_utilizador ID do utilizador que está a receber as notificações
     */
    public static void listarNotificacoesTecnico(String tipo, int id_utilizador) 
    {
        int num_notificacoes = Conexao_BD.notificacoes(tipo, id_utilizador);
        JOptionPane.showMessageDialog(null, 
            "Foi selecionado para realizar " + num_notificacoes + " certificação", 
            "Notificação - Técnico", 
            JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Método auxiliar para abrir a janela de registo de equipamento
     * @author Guilherme Rodrigues
     * @param id_utilizador ID do utilizador que está a registar o equipamento
     */
    private void abrirJanelaRegistarEquipamento(int id_utilizador) 
    {
        JFrame janelaRegistar = new JFrame("Registar Equipamento");
        janelaRegistar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaRegistar.setSize(650, 600);
        janelaRegistar.setLocationRelativeTo(this);
        janelaRegistar.setLayout(new GridBagLayout());
        janelaRegistar.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Registar Equipamento", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaRegistar.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo Marca
        JLabel labelMarca = new JLabel("Marca do Equipamento:");
        labelMarca.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaRegistar.add(labelMarca, gbc);

        JTextField campoMarca = new JTextField();
        campoMarca.setPreferredSize(new Dimension(250, 35));
        campoMarca.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRegistar.add(campoMarca, gbc);

        // Campo Modelo
        JLabel labelModelo = new JLabel("Modelo do Equipamento:");
        labelModelo.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 2;
        janelaRegistar.add(labelModelo, gbc);

        JTextField campoModelo = new JTextField();
        campoModelo.setPreferredSize(new Dimension(250, 35));
        campoModelo.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRegistar.add(campoModelo, gbc);

        // Campo Setor Comercial
        JLabel labelSetor = new JLabel("Setor Comercial:");
        labelSetor.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 3;
        janelaRegistar.add(labelSetor, gbc);

        JTextField campoSetor = new JTextField();
        campoSetor.setPreferredSize(new Dimension(250, 35));
        campoSetor.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRegistar.add(campoSetor, gbc);

        // Campo Potência
        JLabel labelPotencia = new JLabel("Potência:");
        labelPotencia.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 4;
        janelaRegistar.add(labelPotencia, gbc);

        JTextField campoPotencia = new JTextField();
        campoPotencia.setPreferredSize(new Dimension(250, 35));
        campoPotencia.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRegistar.add(campoPotencia, gbc);

        // Campo Amperagem
        JLabel labelAmperagem = new JLabel("Amperagem:");
        labelAmperagem.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 5;
        janelaRegistar.add(labelAmperagem, gbc);

        JTextField campoAmperagem = new JTextField();
        campoAmperagem.setPreferredSize(new Dimension(250, 35));
        campoAmperagem.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRegistar.add(campoAmperagem, gbc);

        // Campo Número do Modelo
        JLabel labelNumModelo = new JLabel("Número do Modelo:");
        labelNumModelo.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 6;
        janelaRegistar.add(labelNumModelo, gbc);

        JTextField campoNumModelo = new JTextField();
        campoNumModelo.setPreferredSize(new Dimension(250, 35));
        campoNumModelo.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaRegistar.add(campoNumModelo, gbc);

        // Label para mostrar SKU gerado e Data
        JLabel labelInfo = new JLabel(" ");
        labelInfo.setFont(new Font("Arial", Font.PLAIN, 12));
        labelInfo.setForeground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 15, 5, 15);
        janelaRegistar.add(labelInfo, gbc);
        gbc.gridwidth = 1;

        // Label para mostrar status da operação
        JLabel labelStatus = new JLabel(" ");
        labelStatus.setFont(new Font("Arial", Font.PLAIN, 14));
        labelStatus.setForeground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 15, 15, 15);
        janelaRegistar.add(labelStatus, gbc);
        gbc.gridwidth = 1;

        // Botão Registar Equipamento
        JButton botaoRegistar = new JButton("Registar Equipamento");
        botaoRegistar.setPreferredSize(new Dimension(200, 40));
        botaoRegistar.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoRegistar.setBackground(new Color(70, 130, 180));
        botaoRegistar.setForeground(Color.WHITE);
        botaoRegistar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String marca = campoMarca.getText().trim();
                String modelo = campoModelo.getText().trim();
                String setor = campoSetor.getText().trim();
                String potenciaTexto = campoPotencia.getText().trim();
                String amperagemTexto = campoAmperagem.getText().trim();
                String numModeloTexto = campoNumModelo.getText().trim();
                
                if (marca.isEmpty() || modelo.isEmpty() || setor.isEmpty() || 
                    potenciaTexto.isEmpty() || amperagemTexto.isEmpty() || numModeloTexto.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaRegistar, "Por favor, preencha todos os campos!");
                    return;
                }
                
                try 
                {
                    float potencia = Float.parseFloat(potenciaTexto);
                    float amperagem = Float.parseFloat(amperagemTexto);
                    int numModelo = Integer.parseInt(numModeloTexto);
                    
                    // Gerar SKU aleatório
                    Random rand = new Random();
                    int skuGerado = rand.nextInt(1000000) + 1;
                    
                    // Data atual
                    LocalDate dataAtual = LocalDate.now();
                    java.sql.Date dataSubmissaoSQL = java.sql.Date.valueOf(dataAtual);
                    
                    // Mostrar informações geradas antes de inserir
                    labelInfo.setText("<html><div style='text-align: center; font-size: 11px;'>" +
                                    "<b>SKU Gerado:</b> " + skuGerado + " | " +
                                    "<b>Data Submissão:</b> " + dataSubmissaoSQL +
                                    "</div></html>");
                    
                    String sql = "INSERT INTO equipamento (id_utilizador, marca_equipamento, modelo_equipamento, sector_comercial_equipamento, " +
                                "potencia, amperagem, sku_equipamento, n_modelo, data_submissao, submetido_certificacao) " +
                                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, id_utilizador);
                    stmt.setString(2, marca);
                    stmt.setString(3, modelo);
                    stmt.setString(4, setor);
                    stmt.setFloat(5, potencia);
                    stmt.setFloat(6, amperagem);
                    stmt.setInt(7, skuGerado);
                    stmt.setInt(8, numModelo);
                    stmt.setDate(9, dataSubmissaoSQL);
                    stmt.setString(10, "Nao submetido");
                    
                    int rowsAffected = stmt.executeUpdate();
                    
                    if (rowsAffected > 0) 
                    {
                        labelStatus.setText("<html><div style='text-align: center;'>" +
                                        "<span style='color: green;'><b>Equipamento inserido com sucesso!</b></span><br>" +
                                        "SKU: " + skuGerado +
                                        "</div></html>");
                        
                        // Limpar todos os campos após sucesso
                        campoMarca.setText("");
                        campoModelo.setText("");
                        campoSetor.setText("");
                        campoPotencia.setText("");
                        campoAmperagem.setText("");
                        campoNumModelo.setText("");
                        labelInfo.setText(" ");
                    } 
                    else 
                    {
                        labelStatus.setText("<html><span style='color: red;'>Falha ao inserir equipamento!</span></html>");
                    }
                    
                    stmt.close();
                    conn.close();
                    
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(janelaRegistar, "Potência, Amperagem e Número do Modelo devem ser números válidos!");
                } 
                catch (SQLException ex) 
                {
                    labelStatus.setText("<html><span style='color: red;'>Erro ao inserir equipamento!</span></html>");
                    JOptionPane.showMessageDialog(janelaRegistar, "Erro ao inserir equipamento: " + ex.getMessage());
                    System.out.println("Erro SQL: " + ex.getMessage());
                }
            }
        });
        gbc.gridy = 9;
        gbc.insets = new Insets(15, 15, 10, 15);
        gbc.gridx = 0;
        janelaRegistar.add(botaoRegistar, gbc);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaRegistar.dispose();
            }
        });
        gbc.gridx = 1;
        janelaRegistar.add(botaoCancelar, gbc);
        
        janelaRegistar.setVisible(true);
    }

    /**
     * Método auxiliar para abrir a janela de realizar pedido de certificação
     * @author Guilherme Rodrigues
     */
    private void abrirJanelaRealizarPedidoCertificacao() 
    {
        JFrame janelaCertificacao = new JFrame("Realizar Pedido de Certificação");
        janelaCertificacao.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaCertificacao.setSize(550, 400);
        janelaCertificacao.setLocationRelativeTo(this);
        janelaCertificacao.setLayout(new GridBagLayout());
        janelaCertificacao.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titulo = new JLabel("Realizar Pedido de Certificação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.ipady = 15;
        janelaCertificacao.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        // Campo ID do Equipamento
        JLabel labelIdEquipamento = new JLabel("ID do Equipamento:");
        labelIdEquipamento.setFont(new Font("Arial", Font.PLAIN, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        janelaCertificacao.add(labelIdEquipamento, gbc);

        JTextField campoIdEquipamento = new JTextField();
        campoIdEquipamento.setPreferredSize(new Dimension(250, 35));
        campoIdEquipamento.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        janelaCertificacao.add(campoIdEquipamento, gbc);

        // Label para mostrar status da operação
        JLabel labelStatus = new JLabel(" ");
        labelStatus.setFont(new Font("Arial", Font.PLAIN, 14));
        labelStatus.setForeground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 15, 20, 15);
        janelaCertificacao.add(labelStatus, gbc);
        gbc.gridwidth = 1;

        // Botão Submeter Pedido
        JButton botaoSubmeter = new JButton("Submeter Pedido");
        botaoSubmeter.setPreferredSize(new Dimension(200, 40));
        botaoSubmeter.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoSubmeter.setBackground(new Color(70, 130, 180));
        botaoSubmeter.setForeground(Color.WHITE);
        botaoSubmeter.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                String idEquipamentoTexto = campoIdEquipamento.getText().trim();
                
                if (idEquipamentoTexto.isEmpty()) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "Por favor, insira o ID do equipamento!");
                    return;
                }
                
                try 
                {
                    int id_equipamento = Integer.parseInt(idEquipamentoTexto);
                    String submetido = "Submetido";
                    
                    String sql = "UPDATE equipamento SET submetido_certificacao = ? WHERE id_equipamento = ?";
                    
                    Conexao_BD conexaoBD = new Conexao_BD();
                    Connection conn = conexaoBD.conexao();
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    
                    stmt.setString(1, submetido);
                    stmt.setInt(2, id_equipamento);
                    
                    int linhasAfetadas = stmt.executeUpdate();
                    
                    if (linhasAfetadas > 0) 
                    {
                        labelStatus.setText("<html><div style='text-align: center;'>" +
                                        "<span style='color: green;'><b>Pedido de Certificação Submetido com sucesso!</b></span><br>" +
                                        "Equipamento ID: " + id_equipamento +
                                        "</div></html>");
                        
                        // Limpar campo após sucesso
                        campoIdEquipamento.setText("");
                    } 
                    else 
                    {
                        labelStatus.setText("<html><div style='text-align: center;'>" +
                                        "<span style='color: red;'><b>Nenhum equipamento encontrado com o ID " + id_equipamento + "</b></span>" +
                                        "</div></html>");
                    }
                    
                    stmt.close();
                    conn.close();
                    
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(janelaCertificacao, "O ID do equipamento deve ser um número válido!");
                } 
                catch (SQLException ex) 
                {
                    labelStatus.setText("<html><span style='color: red;'>Erro ao submeter pedido de certificação!</span></html>");
                    JOptionPane.showMessageDialog(janelaCertificacao, "Erro ao submeter pedido: " + ex.getMessage());
                    System.out.println("Erro SQL: " + ex.getMessage());
                }
            }
        });
        gbc.gridy = 3;
        gbc.insets = new Insets(25, 15, 10, 15);
        gbc.gridx = 0;
        janelaCertificacao.add(botaoSubmeter, gbc);

        // Botão Cancelar
        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setPreferredSize(new Dimension(200, 40));
        botaoCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoCancelar.setBackground(new Color(128, 128, 128));
        botaoCancelar.setForeground(Color.WHITE);
        botaoCancelar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                janelaCertificacao.dispose();
            }
        });
        gbc.gridx = 1;
        janelaCertificacao.add(botaoCancelar, gbc);
        
        janelaCertificacao.setVisible(true);
    }

    /**
     * Método auxiliar para abrir a janela de notificações do fabricante
     * @author Guilherme Rodrigues
     */
    private void abrirJanelaNotificacoesFabricante() 
    {
        JFrame janelaNotificacoes = new JFrame("Notificações do Fabricante");
        janelaNotificacoes.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        janelaNotificacoes.setSize(700, 500);
        janelaNotificacoes.setLocationRelativeTo(this);
        janelaNotificacoes.setLayout(new GridBagLayout());
        janelaNotificacoes.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("Notificações do Fabricante", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.ipady = 15;
        janelaNotificacoes.add(titulo, gbc);
        gbc.gridwidth = 1;
        gbc.ipady = 0;

        JTextArea areaResultados = new JTextArea(15, 50);
        areaResultados.setFont(new Font("Arial", Font.PLAIN, 12));
        areaResultados.setEditable(false);
        areaResultados.setBackground(Color.WHITE);
        areaResultados.setBorder(BorderFactory.createLoweredBevelBorder());

        JScrollPane scrollPane = new JScrollPane(areaResultados);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(10, 15, 20, 15);
        janelaNotificacoes.add(scrollPane, gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.gridwidth = 1;

        JButton botaoNegados = new JButton("Pedidos Negados");
        botaoNegados.setPreferredSize(new Dimension(180, 40));
        botaoNegados.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoNegados.setBackground(new Color(220, 20, 60));
        botaoNegados.setForeground(Color.WHITE);
        botaoNegados.addActionListener(e -> {
            areaResultados.setText("Consultando pedidos de certificação negados...\n\n");

            String sql = "SELECT id_certificacao, id_equipamento FROM equipamento WHERE submetido_certificacao = ?";
            try (
                Connection conn = new Conexao_BD().conexao();
                PreparedStatement pstmt = conn.prepareStatement(sql)
            ) {
                pstmt.setString(1, "Negado");
                ResultSet rs = pstmt.executeQuery();

                StringBuilder resultado = new StringBuilder();
                resultado.append("=== PEDIDOS DE CERTIFICAÇÃO NEGADOS ===\n\n");

                boolean temResultados = false;
                while (rs.next()) {
                    temResultados = true;
                    int id_certificacao = rs.getInt("id_certificacao");
                    int id_equipamento = rs.getInt("id_equipamento");
                    resultado.append("• O pedido de Certificação do equipamento ")
                            .append(id_equipamento)
                            .append(" foi negado por um gestor\n");
                }

                if (!temResultados) {
                    resultado.append("Nenhum pedido de certificação negado encontrado.\n");
                }

                areaResultados.setText(resultado.toString());
            } catch (SQLException ex) {
                areaResultados.setText("Erro ao listar pedidos de certificação negados: " + ex.getMessage());
                System.out.println("Erro SQL: " + ex.getMessage());
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(10, 15, 10, 5);
        janelaNotificacoes.add(botaoNegados, gbc);

        JButton botaoTerminados = new JButton("Pedidos Terminados");
        botaoTerminados.setPreferredSize(new Dimension(180, 40));
        botaoTerminados.setFont(new Font("Arial", Font.PLAIN, 14));
        botaoTerminados.setBackground(new Color(34, 139, 34));
        botaoTerminados.setForeground(Color.WHITE);
        botaoTerminados.addActionListener(e -> {
            areaResultados.setText("Consultando pedidos de certificação terminados...\n\n");

            String sql = "SELECT id_certificacao, id_equipamento FROM equipamento WHERE submetido_certificacao = ?";
            try (
                Connection conn = new Conexao_BD().conexao();
                PreparedStatement pstmt = conn.prepareStatement(sql)
            ) {
                pstmt.setString(1, "terminado");
                ResultSet rs = pstmt.executeQuery();

                StringBuilder resultado = new StringBuilder();
                resultado.append("=== PEDIDOS DE CERTIFICAÇÃO TERMINADOS ===\n\n");

                boolean temResultados = false;
                while (rs.next()) {
                    temResultados = true;
                    int id_certificacao = rs.getInt("id_certificacao");
                    int id_equipamento = rs.getInt("id_equipamento");
                    resultado.append("• O pedido de Certificação do equipamento ")
                            .append(id_equipamento)
                            .append(" foi Terminado\n");
                }

                if (!temResultados) {
                    resultado.append("Nenhum pedido de certificação terminado encontrado.\n");
                }

                areaResultados.setText(resultado.toString());
            } catch (SQLException ex) {
                areaResultados.setText("Erro ao listar pedidos de certificação terminados: " + ex.getMessage());
                System.out.println("Erro SQL: " + ex.getMessage());
            }
        });
        gbc.gridx = 1;
        gbc.insets = new Insets(10, 5, 10, 5);
        janelaNotificacoes.add(botaoTerminados, gbc);

        JButton botaoFechar = new JButton("Fechar");
        botaoFechar.setPreferredSize(new Dimension(180, 40));
        botaoFechar.setFont(new Font("Arial", Font.BOLD, 14));
        botaoFechar.setBackground(new Color(128, 128, 128));
        botaoFechar.setForeground(Color.WHITE);
        botaoFechar.addActionListener(e -> janelaNotificacoes.dispose());
        gbc.gridx = 2;
        gbc.insets = new Insets(10, 5, 10, 15);
        janelaNotificacoes.add(botaoFechar, gbc);

        janelaNotificacoes.setVisible(true);
    }

}